#!/usr/bin/env python3
"""Generate sound effects for Eater Quest."""
import struct
import math


def generate_sfx(filename, samples_fn, duration, sample_rate=44100):
    """Generate a WAV file from a samples function."""
    num_samples = int(duration * sample_rate)
    samples = [samples_fn(i / sample_rate, i, num_samples) for i in range(num_samples)]

    with open(filename, 'wb') as f:
        f.write(b'RIFF')
        f.write(struct.pack('<I', 36 + len(samples) * 2))
        f.write(b'WAVE')
        f.write(b'fmt ')
        f.write(struct.pack('<I', 16))
        f.write(struct.pack('<HHIIHH', 1, 1, sample_rate, sample_rate * 2, 2, 16))
        f.write(b'data')
        f.write(struct.pack('<I', len(samples) * 2))
        for s in samples:
            f.write(struct.pack('<h', s))


def eating_fn(t, i, n):
    """Chomp sound - quick bite with crunch."""
    env = 1.0
    if t < 0.03:
        env = t / 0.03
    elif t > 0.35:
        env = max(0, 1.0 - (t - 0.35) / 0.05)

    s = 0.0
    # Quick down sweep (bite)
    s += 150 * math.sin(2 * math.pi * (800 - 200 * t / 0.1) * 0.1) * math.exp(-t / 0.02) * 0.3
    # Crunch noise
    crunch = math.sin(2 * math.pi * 2000 * t) * math.sin(2 * math.pi * 50 * t)
    s += crunch * 100 * math.exp(-t / 0.05)
    # Chomp thud
    s += 80 * math.sin(2 * math.pi * 120 * t) * math.exp(-t / 0.08)
    # Swallow
    s += 60 * math.sin(2 * math.pi * 200 * t) * math.exp(-(t - 0.1) / 0.05) * (t > 0.1)
    return max(-255, min(255, int(s * env)))


def starvation_fn(t, i, n):
    """Weak fading sound - fading away."""
    s = 0.0
    # Very quiet wind/weakness
    s += 30 * math.sin(2 * math.pi * 100 * t) * math.sin(2 * math.pi * 0.5 * t)
    # Fading heartbeat
    if t < 2.0:
        beat = math.sin(2 * math.pi * t * 0.8)
        s += 40 * beat * math.sin(2 * math.pi * 80 * t) * math.exp(-t * 0.8)
    # Complete fade
    env = 1.0
    if t > 1.5:
        env = max(0, 1.0 - (t - 1.5) / 0.5)
    return max(-255, min(255, int(s * env * 0.7)))


def levelup_fn(t, i, n):
    """Ascending triumphant sound."""
    s = 0.0
    # Ascending notes
    for j, freq in enumerate([523, 659, 784, 1047]):  # C5, E5, G5, C6
        start = j * 0.1
        if t >= start:
            s += 60 * math.sin(2 * math.pi * freq * (t - start)) * math.exp(-(t - start) * 3)
    # Shimmer
    s += 40 * math.sin(2 * math.pi * 2000 * t) * math.sin(2 * math.pi * 3 * t) * math.exp(-t * 2)
    # Bass note
    s += 50 * math.sin(2 * math.pi * 262 * t) * math.exp(-t * 2)
    env = 1.0
    if t > 0.8:
        env = max(0, 1.0 - (t - 0.8) / 0.2)
    return max(-255, min(255, int(s * env)))


def hatch_fn(t, i, n):
    """Egg hatching - cracking and breaking free."""
    s = 0.0
    # First cracks
    for j in range(5):
        crack_time = j * 0.08
        if t >= crack_time:
            crack = math.sin(2 * math.pi * 3000 * (t - crack_time)) * math.exp(-((t - crack_time) / 0.02))
            s += 80 * crack * math.exp(-t * 2)
    # Big break
    if t > 0.35:
        s += 120 * math.sin(2 * math.pi * 400 * t) * math.exp(-(t - 0.35) / 0.1)
        # Sparkle
        s += 50 * math.sin(2 * math.pi * 1500 * t) * math.sin(2 * math.pi * 20 * t) * math.exp(-(t - 0.35) * 3)
    env = 1.0
    if t > 0.8:
        env = max(0, 1.0 - (t - 0.8) / 0.2)
    return max(-255, min(255, int(s * env)))


def dice_roll_fn(t, i, n):
    """Dice rolling - quick rattling sound."""
    s = 0.0
    env = 1.0
    if t < 0.02:
        env = t / 0.02
    elif t > 0.2:
        env = max(0, 1.0 - (t - 0.2) / 0.05)
    for j in range(8):
        start = j * 0.02
        if t >= start:
            s += 60 * math.sin(2 * math.pi * (500 + 300 * math.sin(20 * (t - start))) * (t - start)) * math.exp(-(t - start) / 0.03)
    return max(-255, min(255, int(s * env * 0.5)))


def generate_all():
    generate_sfx('sfx_eating.wav', eating_fn, 0.4)
    print("Created sfx_eating.ogg")
    generate_sfx('sfx_starvation.wav', starvation_fn, 2.0)
    print("Created sfx_starvation.ogg")
    generate_sfx('sfx_levelup.wav', levelup_fn, 1.0)
    print("Created sfx_levelup.ogg")
    generate_sfx('sfx_hatch.wav', hatch_fn, 1.0)
    print("Created sfx_hatch.ogg")
    generate_sfx('dice_roll.wav', dice_roll_fn, 0.25)
    print("Created dice_roll.ogg")
    print("Done!")


if __name__ == '__main__':
    generate_all()
