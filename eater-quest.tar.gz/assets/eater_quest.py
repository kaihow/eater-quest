#!/usr/bin/env python3
"""Eater Quest - A Pygame survival game about a firefish goby. Complete rewrite with animated backgrounds, cute critters, and zone-specific environments."""
import random, sys, os, math, time
from fractions import Fraction
import pygame

# ── constants ──────────────────────────────────────────────────────────
W, H = 1080, 720  # native 3:2 landscape game coordinates
FPS = 60

BG_EGG = (20, 40, 80)
BG_OCEAN = (30, 60, 120)
BG_MANGROVE = (20, 80, 60)
BG_KELP = (20, 50, 100)
BG_CORAL = (60, 30, 80)
BG_NIGHT = (10, 15, 35)
BG_OVER = (40, 10, 10)
BG_WIN = (10, 50, 40)

# ── cute critter names by zone (20+ each) ─────────────────────────────
CRITTER_NAMES = {
    "open_ocean": [
        "Tiny Tiddly Shrimp", "Miniature Sparkle Squid", "Baby Bouncy Crab",
        "Little Bubbles the Minnow", "Pint-sized Shimmery Shrimp",
        "Small Squiggly Squid", "Tiny Tiny Crabby", "Small Shimmer Shrimp",
        "Mini Shrimplet", "Little Luminous Lobster", "Fuzzy Fiddler Crab",
        "Tiny Teacup Squid", "Little Wiggly Worm Crab", "Mini Minty Minnow",
        "Tiny Tippy Shrimp", "Little Bouncy Bay Crab", "Mini Magic Minnow",
        "Tiny Twinkling Squid", "Little Bitty Lobster", "Mini Sparkle Shrimp",
        "Tiny Tumbleweed Crab", "Little Glitter Minnow", "Mini Pearly Shrimp",
        "Tiny Dancer Squid", "Little Puddle Crab", "Mini Bitty Minnow",
        "Tiny Curious Crab", "Little Sunny Shrimp", "Mini Dreamy Squid",
        "Tiny Wobble Shrimp", "Little Happy Minnow", "Mini Curly Crab",
        "Tiny Shiny Shrimp", "Little Bouncy Squid", "Mini Jumpy Minnow",
        "Tiny Sparkle Crab", "Little Glowing Shrimp", "Mini Dandy Lobster",
        "Tiny Curious Minnow", "Little Snuggle Squid", "Mini Bitty Crab",
        "Tiny Tasty Shrimp", "Little Bouncy Shrimp", "Mini Curious Squid",
        "Tiny Little Crab", "Little Sweet Shrimp", "Mini Tiny Minnow",
        "Tiny Sparkly Squid", "Little Bubbly Crab", "Mini Shrimple Minnow",
        "Tiny Bouncy Squid", "Little Curious Shrimp", "Mini Sparkle Crab",
        "Tiny Happy Crab", "Little Tiny Squid", "Mini Bubbly Shrimp",
        "Tiny Bouncy Lobster", "Little Shimmery Minnow", "Mini Curly Squid",
        "Tiny Dainty Crab", "Little Sparkling Shrimp", "Mini Tiny Crab",
    ],
    "mangrove": [
        "Tiny Mangrove Mite", "Little Root Crab", "Mini Barnacle Buddy",
        "Small Snappy Shrimp", "Tiny Mudskipper Mate", "Little Mangrove Minnow",
        "Mini Mangrove Muncher", "Tiny Mud Crabby", "Little Root Snapper",
        "Mini Mangrove Shrimp", "Tiny Mudskipper Minnow", "Little Mangrove Mite",
        "Mini Mudbug Baby", "Tiny Mangrove Snail", "Little Rootling Shrimp",
        "Mini Mangrove Minnow", "Tiny Mud Puddle Crab", "Little Mangrove Munchkin",
        "Mini Snappy Shrimp", "Tiny Mangrove Muffin", "Little Root Crabby",
        "Mini Mangrove Minnie", "Tiny Mudskipper Snuggles", "Little Mangrove Sprout",
        "Mini Mangrove Midge", "Tiny Root Snail", "Little Mud Crab",
        "Mini Mangrove Mitey", "Tiny Mangrove Munch", "Little Mangrove Min",
        "Mini Root Shrimp", "Tiny Mangrove Muff", "Little Mud Snapper",
        "Mini Mangrove Mini", "Tiny Mangrove Minnowette", "Little Mangrove Rootling",
        "Mini Mudskipper Minnie", "Tiny Mangrove Mudbug", "Little Mangrove Minion",
        "Mini Mangrove Mud", "Tiny Mangrove Minnowkin", "Little Mangrove Min",
        "Mini Mangrove Minnowette", "Tiny Mangrove Mitey Mite", "Little Mangrove Minnow",
        "Mini Mangrove Mudskimmer", "Tiny Mangrove Muncherette", "Little Mangrove Mite",
    ],
    "kelp_forest": [
        "Tiny Kelp Krill", "Little Kelp Crab", "Mini Kelp Shrimp",
        "Small Kelp Squid", "Tiny Kelp Minnow", "Little Kelp Crabby",
        "Mini Kelp Krabbie", "Tiny Kelp Shrimplet", "Little Kelp Squidlet",
        "Mini Kelp Minnowette", "Tiny Kelp Krillkin", "Little Kelp Crabble",
        "Mini Kelp Shrimpette", "Tiny Kelp Squidkin", "Little Kelp Minnowkin",
        "Mini Kelp Krillie", "Tiny Kelp Crabette", "Little Kelp Shrimpkie",
        "Mini Kelp Squidette", "Tiny Kelp Minnowkin", "Little Kelp Krilllet",
        "Mini Kelp Crabbie", "Tiny Kelp Shrimpette", "Little Kelp Squidkin",
        "Mini Kelp Minnowette", "Tiny Kelp Krillkin", "Little Kelp Crabble",
        "Mini Kelp Shrimplet", "Tiny Kelp Squidette", "Little Kelp Minnowkin",
        "Mini Kelp Krillie", "Tiny Kelp Crabette", "Little Kelp Shrimpkie",
        "Mini Kelp Squidlette", "Tiny Kelp Minnowette", "Little Kelp Krilllet",
        "Mini Kelp Crabbiekin", "Tiny Kelp Shrimpette", "Little Kelp Squidkin",
        "Mini Kelp Minnowette", "Tiny Kelp Krillkin", "Little Kelp Crabblekin",
        "Mini Kelp Shrimple", "Tiny Kelp Squidlet", "Little Kelp Minnowette",
        "Mini Kelp Krillkin", "Tiny Kelp Crabette", "Little Kelp Shrimpkie",
        "Mini Kelp Squidlette", "Tiny Kelp Minnowkin", "Little Kelp Krilllette",
        "Mini Kelp Crabbie", "Tiny Kelp Shrimpette", "Little Kelp Squidkinette",
    ],
    "coral_reef": [
        "Tiny Coral Crab", "Little Reef Shrimp", "Mini Coral Squid",
        "Small Reef Minnow", "Tiny Coral Shrimp", "Little Reef Crabby",
        "Mini Coral Krill", "Tiny Reef Squid", "Little Coral Minnow",
        "Mini Reef Shrimpette", "Tiny Coral Crabble", "Little Reef Squidkin",
        "Mini Coral Minnowette", "Tiny Reef Krabbie", "Little Coral Shrimplet",
        "Mini Reef Squidlette", "Tiny Coral Minnowkin", "Little Reef Crabette",
        "Mini Coral Shrimpette", "Tiny Reef Squidkin", "Little Coral Krillkin",
        "Mini Reef Minnowette", "Tiny Coral Crabble", "Little Reef Shrimplet",
        "Mini Coral Squidlette", "Tiny Reef Minnowkin", "Little Coral Crabette",
        "Mini Reef Shrimpette", "Tiny Coral Squidkin", "Little Reef Krillkin",
        "Mini Coral Minnowette", "Tiny Reef Crabble", "Little Coral Shrimplet",
        "Mini Reef Squidlette", "Tiny Coral Minnowkin", "Little Reef Crabette",
        "Mini Coral Shrimpette", "Tiny Reef Squidkin", "Little Coral Krillkin",
        "Mini Reef Minnowette", "Tiny Coral Crabble", "Little Reef Shrimplet",
        "Mini Coral Squidlette", "Tiny Reef Minnowkin", "Little Reef Crabette",
        "Mini Coral Shrimpette", "Tiny Reef Squidkin", "Little Coral Krillkin",
        "Mini Reef Minnowette", "Tiny Coral Crabble", "Little Reef Shrimplet",
        "Mini Coral Squidlette", "Tiny Reef Minnowkin", "Little Coral Crabette",
        "Mini Reef Shrimpette", "Tiny Reef Squidkinette", "Little Coral Krillkin",
    ],
}

CRITTER_DRAW_TYPES = ["shrimp", "squid", "crab", "minnow", "lobster", "octopus", "krill", "snail", "mudskipper", "barnacle", "worm", "midge"]

CARD_COLORS = [(255, 200, 100), (100, 200, 255), (255, 140, 140)]


def get_zone(size):
    if size < 1: return "open_ocean"
    if size < 2: return "mangrove"
    if size < 3: return "kelp_forest"
    return "coral_reef"

def get_zone_name(size):
    if size < 1: return "Open Ocean"
    if size < 2: return "Mangrove Forest"
    if size < 3: return "Kelp Forest"
    return "Coral Reef"

def get_critters(size, n=3):
    zone = get_zone(size)
    pool = list(CRITTER_NAMES[zone])
    while len(pool) < n:
        pool.extend(CRITTER_NAMES[zone])
    names = []
    for _ in range(n):
        name = random.choice(pool)
        names.append(name)
    return names

def get_critter_type(name):
    if not name:
        return "shrimp"
    name_lower = name.lower()
    words = name_lower.split()
    matches = []
    for t in CRITTER_DRAW_TYPES:
        for w in words:
            if t in w or w in t:
                matches.append(t)
                break
        if t in name_lower:
            if t not in matches:
                matches.append(t)
    if matches:
        # Prefer the most specific (longest) match, or the last one if tied
        best = max(matches, key=lambda x: (len(x), matches.index(x)))
        return best
    return "shrimp"

def get_boosts(size):
    return [Fraction(3, 2), Fraction(9, 4), Fraction(7, 2)]

def fmt_speed(f):
    """Format a Fraction/int as a simplified mixed number string."""
    if not isinstance(f, Fraction):
        f = Fraction(f)
    if f.denominator == 1:
        return str(f.numerator)
    whole = f.numerator // f.denominator
    rem = f.numerator % f.denominator
    if whole == 0:
        return f"{rem}/{f.denominator}"
    return f"{whole} {rem}/{f.denominator}"

def growth_amount(n):
    return {0:0, 1:0.0625, 2:0.125, 3:0.25}.get(n, 0.25)

def fmt_size(s):
    if s < 0.25: return f"{s*16:.0f}\""
    if s < 1: return f"{s*4:.1f}/4\""
    return f"{s:.2f}\""

def fmt_size_short(s):
    return f"{s:.2f}\""

def fish_display_size(size):
    frac = max(0.0, min(1.0, (size - 0.25) / (4.0 - 0.25)))
    return int(20 + frac * 20)

NIGHT_EATER_SIZE = 22


# ── fonts ──────────────────────────────────────────────────────────────
pygame.font.init()
# Bundle Lato with the game so Pygbag/Safari never falls back to a bitmap
# monospace font.  Keep the established font sizes and UI geometry.
FONT_DIR = os.path.dirname(os.path.abspath(__file__))
def game_font(size, bold=False):
    filename = "Lato-Bold.ttf" if bold else "Lato-Regular.ttf"
    path = os.path.join(FONT_DIR, "fonts", filename)
    return pygame.font.Font(path, size)

F14 = game_font(24, bold=False)
F16 = game_font(27, bold=True)
F18 = game_font(31, bold=False)
F20 = game_font(34, bold=True)
F22 = game_font(37, bold=True)
F24 = game_font(41, bold=True)
F28 = game_font(48, bold=True)
F32 = game_font(54, bold=True)
F36 = game_font(61, bold=True)
F40 = game_font(68, bold=True)
F52 = game_font(88, bold=True)

def _fit_font_render(font, label, color, max_width=None, max_height=None):
    rendered = font.render(str(label), True, color)
    if max_width and rendered.get_width() > max_width or max_height and rendered.get_height() > max_height:
        factor = min(1.0, max_width / max(1, rendered.get_width()) if max_width else 1.0,
                     max_height / max(1, rendered.get_height()) if max_height else 1.0)
        rendered = pygame.transform.smoothscale(rendered,
            (max(1, round(rendered.get_width() * factor)), max(1, round(rendered.get_height() * factor))))
    return rendered

def draw_text(surf, text, pos, color=(255,255,255), font=None):
    s = _fit_font_render(font or F20, text, color, min(W - 24, 2 * min(pos[0], W-pos[0])-8))
    r = s.get_rect()
    r.center = pos
    surf.blit(s, r)

def draw_text_top(surf, text, pos, color=(255,255,255), font=None):
    s = _fit_font_render(font or F20, text, color, max(20, pos[0]-12))
    r = s.get_rect()
    r.topright = pos
    surf.blit(s, r)

def draw_text_left(surf, text, pos, color=(255,255,255), font=None):
    s = _fit_font_render(font or F20, text, color, max(20, W-pos[0]-12))
    r = s.get_rect()
    r.topleft = pos
    surf.blit(s, r)

def draw_multi_btn(surf, lines, rect, hover=False, enabled=True, font=F20):
    """Button with multiple text lines."""
    if not enabled:
        c = (80,80,80)
        tc = (150,150,150)
    else:
        c = (100,200,255) if hover else (50,130,200)
        tc = (255,255,255)
    pygame.draw.rect(surf, c, rect, border_radius=8)
    pygame.draw.rect(surf, (255,255,255), rect, 2, border_radius=8)
    spacing = rect.height // (len(lines) + 1)
    for i, line in enumerate(lines):
        y = rect.centery - (len(lines) - 1) * spacing // 2 + i * spacing
        label = _fit_font_render(font, line, tc, rect.width - 16,
                                 min(45, rect.height // len(lines) - 7))
        surf.blit(label, label.get_rect(center=(rect.centerx, y)))

def draw_multi_btn_glow(surf, lines, rect, hover=False, enabled=True, tick=0, font=F22):
    """Button with animated glow and multiple text lines."""
    if not enabled:
        c = (80,80,80)
        tc = (150,150,150)
        glow_alpha = 0
    else:
        base = 60 + 30 * math.sin(tick * 0.08)
        if hover:
            base = 120 + 40 * math.sin(tick * 0.12)
            c = (100,230,255)
        else:
            c = (50,140,210)
        tc = (255,255,255)
        glow_alpha = int(base * 0.4)
    pygame.draw.rect(surf, c, rect, border_radius=8)
    if glow_alpha > 10:
        glow_color = (80, 180, 255)
        for r in range(6):
            alpha = glow_alpha * (6 - r) // 6
            gs = pygame.Surface((rect.width + 16 + r*4, rect.height + 16 + r*4), pygame.SRCALPHA)
            gs.set_alpha(alpha)
            pygame.draw.rect(gs, glow_color, gs.get_rect(), border_radius=12 + r*2)
            surf.blit(gs, (rect.x - 8 - r*2, rect.y - 8 - r*2))
    pygame.draw.rect(surf, (255,255,255,200), rect, 2, border_radius=8)
    spacing = rect.height // (len(lines) + 1)
    for i, line in enumerate(lines):
        y = rect.centery - (len(lines) - 1) * spacing // 2 + i * spacing
        label = _fit_font_render(font, line, tc, rect.width - 16,
                                 min(45, rect.height // len(lines) - 7))
        surf.blit(label, label.get_rect(center=(rect.centerx, y)))

def draw_btn(surf, text, rect, hover=False, enabled=True):
    draw_multi_btn(surf, [text], rect, hover, enabled)

def draw_btn_glow(surf, text, rect, hover=False, enabled=True, tick=0):
    draw_multi_btn_glow(surf, [text], rect, hover, enabled, tick)

_DICE_FONTS = {}
def _dice_font(height):
    if height not in _DICE_FONTS:
        _DICE_FONTS[height] = game_font(height, bold=True)
    return _DICE_FONTS[height]

def draw_die(surf, x, y, value, sides=10, color=(60, 180, 255), rolling=False):
    sz = 52  # larger dice sized for native 1080x720 display
    pts = []
    for i in range(sides):
        angle = math.pi/2 + (2*math.pi*i/sides) - (math.pi/sides)
        px = x + sz * math.cos(angle)
        py = y + sz * math.sin(angle)
        if rolling:
            px += (pygame.time.get_ticks() % 6) * 3 * ((-1) ** i)
            py += (pygame.time.get_ticks() % 6) * 3 * ((-1) ** (i+1)) * 0.5
        pts.append((px, py))
    draw_color = (255, 80, 60) if rolling else color
    pygame.draw.polygon(surf, draw_color, pts)
    # Fit fractions and mixed numbers inside the die instead of overflowing.
    label = str(value)
    font = F36 if len(label) <= 2 else F28 if len(label) <= 3 else F22 if len(label) <= 5 else F18
    # Condensed sans-serif digits use considerably less horizontal space.
    font = _dice_font(font.get_height())
    rendered = font.render(label, True, (0, 0, 0))
    max_w, max_h = int(sz * 1.48), int(sz * 1.12)
    if rendered.get_width() > max_w or rendered.get_height() > max_h:
        factor = min(max_w / max(1, rendered.get_width()), max_h / max(1, rendered.get_height()))
        rendered = pygame.transform.smoothscale(rendered, (max(1, int(rendered.get_width() * factor)), max(1, int(rendered.get_height() * factor))))
    surf.blit(rendered, rendered.get_rect(center=(x, y)))

# ── ocean background renderer ──────────────────────────────────────────

class OceanBackground:
    """Handles animated backgrounds for all zones and night phase."""

    def __init__(self):
        self.tick = 0
        self.jellyfish = []
        self.bubbles = []
        self.whale = None
        self.whale_timer = 0
        self.light_rays = []
        self.kelp_stalks = []
        self.mangrove_roots = []
        self.corals = []
        self.sand_fish = []
        self._init_elements()

    def _init_elements(self):
        self.jellyfish = []
        for i in range(8):
            self.jellyfish.append({
                "x": random.randint(50, W - 50),
                "y": random.randint(80, H - 50),
                "size": random.randint(8, 18),
                "speed": random.uniform(0.3, 0.8),
                "phase": random.uniform(0, 6.28),
                "color": random.choice([
                    (255, 180, 200, 100), (200, 200, 255, 90),
                    (255, 255, 200, 80), (200, 255, 220, 100),
                ]),
            })

        self.bubbles = []
        for i in range(25):
            self.bubbles.append({
                "x": random.randint(0, W),
                "y": random.randint(0, H),
                "size": random.randint(1, 4),
                "speed": random.uniform(0.5, 1.5),
                "wobble": random.uniform(0, 6.28),
            })

        self.whale = None
        self.whale_timer = random.randint(900, 2100)

        self.light_rays = []
        for i in range(10):
            self.light_rays.append({
                "x": random.randint(-50, W + 50),
                "width": random.randint(12, 25),
                "opacity": random.randint(5, 18),
                "speed": random.uniform(0.08, 0.25),
            })

        self.kelp_stalks = []
        for i in range(14):
            self.kelp_stalks.append({
                "x": random.randint(30, W - 30),
                "height": random.randint(130, 280),
                "phase": random.uniform(0, 6.28),
                "width": random.randint(4, 8),
            })

        self.mangrove_roots = []
        for i in range(18):
            self.mangrove_roots.append({
                "x": random.randint(10, W - 10),
                "length": random.randint(90, 220),
                "segments": random.randint(3, 6),
                "phase": random.uniform(0, 6.28),
            })

        self.corals = []
        for i in range(18):
            self.corals.append({
                "x": random.randint(20, W - 20),
                "height": random.randint(30, 70),
                "type": random.randint(0, 3),
                "color": random.choice([
                    (255, 80, 80), (255, 150, 40), (200, 60, 255),
                    (255, 200, 40), (80, 200, 255), (255, 100, 160), (60, 255, 130),
                ]),
            })

        self.sand_fish = []
        for i in range(5):
            self.sand_fish.append({
                "x": random.randint(0, W),
                "y": H - random.randint(30, 55),
                "speed": random.uniform(0.3, 0.8),
                "dir": random.choice([-1, 1]),
                "color": random.choice([(200, 180, 120), (180, 160, 100), (220, 190, 140)]),
            })

    def update(self):
        self.tick += 1
        for j in self.jellyfish:
            j["phase"] += 0.03
            j["y"] -= j["speed"] * 0.25
            j["x"] += math.sin(self.tick * 0.01 + j["phase"]) * 0.15
            if j["y"] < -50:
                j["y"] = H + 50
                j["x"] = random.randint(50, W - 50)
        for b in self.bubbles:
            b["y"] -= b["speed"]
            b["x"] += math.sin(self.tick * 0.05 + b["wobble"]) * 0.3
            if b["y"] < -10:
                b["y"] = H + 10
                b["x"] = random.randint(0, W)
        if self.whale:
            self.whale["x"] += self.whale["speed"]
            if self.whale["x"] > W + 250:
                self.whale = None
                self.whale_timer = random.randint(1200, 2400)
        else:
            self.whale_timer -= 1
            if self.whale_timer <= 0:
                self.whale = {"x": -250, "y": random.randint(40, H // 2 - 20), "speed": 0.25, "size": 130}
        for r in self.light_rays:
            r["x"] += r["speed"]
            if r["x"] > W + 40:
                r["x"] = -r["width"]
                r["opacity"] = random.randint(4, 18)
        for f in self.sand_fish:
            f["x"] += f["speed"] * f["dir"]
            if f["x"] < -30:
                f["x"] = W + 30
                f["dir"] = -1
            if f["x"] > W + 30:
                f["x"] = -30
                f["dir"] = 1

    def _draw_jellyfish(self, surf, j):
        x, y = int(j["x"]), int(j["y"])
        sz = j["size"]
        pulse = 1.0 + math.sin(j["phase"]) * 0.15
        col = j["color"]
        bw = int(sz * pulse)
        bh = int(sz * 0.7)
        pygame.draw.ellipse(surf, (col[0], col[1], col[2], col[3]), (x - bw, y - bh, bw * 2, bh))
        pygame.draw.ellipse(surf, (255, 255, 255, 50), (x - bw // 2, y - bh, bw, bh // 2))
        tc = 4
        for i in range(tc):
            tx = x - bw + (i * 2 * bw // (tc - 1)) if tc > 1 else x
            wave = math.sin(self.tick * 0.05 + i * 1.5) * 3
            tl = int(sz * 0.8 + math.sin(j["phase"] + i) * 2)
            pts = []
            for s in range(7):
                sy = y + s * tl // 6
                sx = tx + wave * (s / 6)
                pts.append((sx, sy))
            pygame.draw.lines(surf, (col[0], col[1], col[2], col[3] // 2), False, pts, 1)

    def _draw_bubble(self, surf, b):
        x, y = int(b["x"]), int(b["y"])
        sz = b["size"]
        pygame.draw.circle(surf, (200, 220, 255, 100), (x, y), sz, 1)
        pygame.draw.circle(surf, (255, 255, 255, 80), (x - 1, y - 1), max(1, sz // 3), 1)

    def _draw_whale(self, surf, w):
        x, y = int(w["x"]), int(w["y"])
        sz = w["size"]
        asurf = pygame.Surface((sz * 3, sz * 2), pygame.SRCALPHA)
        pygame.draw.ellipse(asurf, (15, 20, 40, 60), (0, sz * 0.3, sz * 2.5, sz * 0.8))
        pygame.draw.ellipse(asurf, (15, 20, 40, 60), (sz * 2.2, sz * 0.3, sz * 0.5, sz * 0.6))
        tp = [(0, sz * 0.7), (-sz * 0.3, 0), (-sz * 0.15, sz * 0.5), (-sz * 0.2, sz * 1.0), (0, sz * 0.7), (sz * 0.1, sz * 1.0)]
        pygame.draw.polygon(asurf, (15, 20, 40, 60), tp)
        pygame.draw.polygon(asurf, (15, 20, 40, 60), [(sz * 1.2, sz * 0.9), (sz * 1.5, sz * 1.5), (sz * 1.0, sz * 1.2)])
        surf.blit(asurf, (x - sz * 2, y - sz))

    def draw_open_ocean(self, surf):
        surf.fill((15, 30, 80))
        for y in range(0, H, 2):
            ratio = y / H
            r = int(15 + ratio * 35)
            g = int(30 + ratio * 65)
            b = int(80 + ratio * 75)
            pygame.draw.line(surf, (r, g, b), (0, y), (W, y))
        for ray in self.light_rays:
            rs = pygame.Surface((int(ray["width"]), H), pygame.SRCALPHA)
            alpha = int(ray["opacity"] + 5 * math.sin(self.tick * 0.01 + ray["x"]))
            for y in range(0, H, 4):
                a = max(0, alpha - int(y * alpha / H * 1.5))
                pygame.draw.line(rs, (200, 230, 255, a), (0, y), (0, y + 4))
            surf.blit(rs, (int(ray["x"]), 0))
        for j in self.jellyfish:
            self._draw_jellyfish(surf, j)
        for b in self.bubbles:
            self._draw_bubble(surf, b)
        if self.whale:
            self._draw_whale(surf, self.whale)
        for f in self.sand_fish:
            self._draw_sand_fish(surf, f)

    def draw_mangrove(self, surf):
        surf.fill((10, 30, 20))
        for y in range(0, H, 2):
            ratio = y / H
            r = int(10 + ratio * 25)
            g = int(30 + ratio * 70)
            b = int(20 + ratio * 40)
            pygame.draw.line(surf, (r, g, b), (0, y), (W, y))
        for root in self.mangrove_roots:
            x = int(root["x"])
            color = (70, 50, 25)
            segs = root["segments"]
            length = int(root["length"])
            sway = math.sin(self.tick * 0.01 + root["phase"]) * 5
            pts = [(x, 0)]
            for i in range(1, segs + 1):
                frac = i / segs
                nx = x + math.sin(root["phase"] + i * 0.7) * 15 * frac + sway * frac
                ny = length * frac
                pts.append((int(nx), int(ny)))
            pygame.draw.lines(surf, color, False, pts, max(2, int(4 - length / 60)))
        for j in self.jellyfish[:3]:
            self._draw_jellyfish(surf, j)
        for b in self.bubbles[:8]:
            self._draw_bubble(surf, b)
        for f in self.sand_fish:
            self._draw_sand_fish(surf, f)

    def draw_kelp_forest(self, surf):
        surf.fill((10, 25, 20))
        for y in range(0, H, 2):
            ratio = y / H
            r = int(10 + ratio * 15)
            g = int(25 + ratio * 50)
            b = int(20 + ratio * 60)
            pygame.draw.line(surf, (r, g, b), (0, y), (W, y))
        for stalk in self.kelp_stalks:
            x = int(stalk["x"])
            height = int(stalk["height"])
            width = int(stalk["width"])
            bc = (20, 80, 25)
            tc = (40, 130, 45)
            sway = math.sin(self.tick * 0.015 + stalk["phase"]) * 8
            pts = [(x, H)]
            for i in range(20):
                frac = i / 20
                nx = x + sway * frac * frac
                ny = H - height * frac
                pts.append((int(nx), int(ny)))
            pygame.draw.lines(surf, bc, False, pts, width)
            pygame.draw.lines(surf, tc, False, pts, max(1, width - 2))
            for frac in [0.2, 0.4, 0.6, 0.8]:
                lx = x + sway * frac * frac
                ly = H - int(height * frac)
                ld = 1 if frac % 0.5 < 0.25 else -1
                lp = [(lx, ly), (lx + 14 * ld + sway * 0.2, ly - 7), (lx + 10 * ld + sway * 0.3, ly - 2), (lx, ly)]
                pygame.draw.polygon(surf, tc, lp)
        for b in self.bubbles[:10]:
            self._draw_bubble(surf, b)
        for f in self.sand_fish:
            self._draw_sand_fish(surf, f)

    def draw_coral_reef(self, surf):
        surf.fill((15, 35, 50))
        for y in range(0, H, 2):
            ratio = y / H
            r = int(15 + ratio * 25)
            g = int(35 + ratio * 45)
            b = int(50 + ratio * 50)
            pygame.draw.line(surf, (r, g, b), (0, y), (W, y))
        for x in range(0, W, 4):
            shade = 155 + random.randint(-3, 3)
            pygame.draw.line(surf, (shade, shade - 18, shade - 35), (x, H - 55), (x, H))
        for coral in self.corals:
            self._draw_coral(surf, coral)
        for b in self.bubbles[:10]:
            self._draw_bubble(surf, b)

    def _draw_coral(self, surf, c):
        x = int(c["x"])
        h = int(c["height"])
        color = c["color"]
        ct = c["type"]
        by = H - 55
        if ct == 0:
            pygame.draw.arc(surf, color, (x - h, by - h, h * 2, h * 2), math.pi, 0, 4)
            for i in range(3):
                rr = h * 0.25 * (i + 1)
                pygame.draw.arc(surf, (color[0]//2, color[1]//2, color[2]//2), (x - rr, by - rr, rr * 2, rr * 2), math.pi, 0, 2)
        elif ct == 1:
            br = 4
            for i in range(br):
                angle = -math.pi/2 + (i / max(1, br-1)) * math.pi - math.pi/4
                pts = [(x, by)]
                for s in range(1, 6):
                    frac = s / 5
                    bx = x + math.cos(angle) * h * frac + math.sin(self.tick * 0.02 + i) * 2 * frac
                    by2 = by + math.sin(angle) * h * frac * 0.3
                    pts.append((int(bx), int(by2)))
                pygame.draw.lines(surf, color, False, pts, 3)
        elif ct == 2:
            for i in range(3):
                tx = x + i * 8 - 8
                th = h * (0.6 + 0.4 * math.sin(i))
                pygame.draw.rect(surf, color, (tx - 4, by - th, 8, th), border_radius=3)
                pygame.draw.circle(surf, (color[0]//2, color[1]//2, color[2]//2), (tx, int(by - th)), 4)
        else:
            pts = [(x, by)]
            for i in range(8):
                angle = -math.pi/2 + (i / 7) * math.pi
                rr = h * 0.8
                fx = x + int(rr * math.cos(angle))
                fy = by + int(rr * math.sin(angle) * 0.5)
                pts.append((fx, fy))
            pts.append((x, by))
            pygame.draw.polygon(surf, (*color[:3], 180), pts)

    def draw_night(self, surf):
        surf.fill((4, 6, 20))
        for y in range(0, H, 2):
            ratio = y / H
            r = int(4 + ratio * 8)
            g = int(6 + ratio * 10)
            b = int(20 + ratio * 18)
            pygame.draw.line(surf, (r, g, b), (0, y), (W, y))
        for i in range(25):
            sx = (i * 137 + self.tick * 0.02) % W
            sy = (i * 89) % (H // 2)
            tw = 80 + 120 * ((math.sin(self.tick * 0.03 + i * 2.5) + 1) / 2)
            pygame.draw.circle(surf, (int(tw), int(tw), int(tw + 20)), (int(sx), int(sy)), 1)
        for j in self.jellyfish[:2]:
            j["y"] -= 0.08
            if j["y"] < -30:
                j["y"] = H
            self._draw_jellyfish(surf, j)

    def _draw_sand_fish(self, surf, f):
        x, y = int(f["x"]), int(f["y"])
        c = f["color"]
        t = self.tick * 0.1
        wobble = math.sin(t) * 1
        pygame.draw.ellipse(surf, c, (x - 6, y - 3 + wobble, 12, 6))
        pygame.draw.polygon(surf, c, [(x + 6, y + wobble), (x + 12, y - 4 + wobble), (x + 12, y + 4 + wobble)])
        pygame.draw.circle(surf, (0, 0, 0), (x - 3, int(y - 1 + wobble)), 1)


# ── critter drawing ────────────────────────────────────────────────────

class CritterRenderer:
    """Draws animated critter sprites."""

    def __init__(self):
        self.tick = 0

    def update(self):
        self.tick += 1

    def draw(self, surf, name, cx, cy, size=40):
        ctype = get_critter_type(name)
        fn = getattr(self, "draw_" + ctype, self.draw_shrimp)
        fn(surf, name, cx, cy, size)

    def _a(self, phase=0.0):
        return math.sin(self.tick * 0.08 + phase)

    def draw_shrimp(self, surf, name, cx, cy, size):
        s = size * 0.5
        c1, c2 = (255, 140, 100), (255, 180, 140)
        a = self._a()
        pts = []
        for i in range(12):
            frac = i / 11
            angle = math.pi * 0.5 - frac * math.pi * 0.8
            bx = cx + math.cos(angle) * s * 0.8 + math.sin(frac * 3 + a) * 2
            by = cy - s * 0.5 + math.sin(angle) * s * 0.5
            pts.append((int(bx), int(by)))
        pygame.draw.lines(surf, c1, False, pts, max(1, int(s * 0.4)))
        for i in range(5):
            lf = (i + 1) / 6
            lx = cx - s * 0.3 + lf * s * 0.6
            ly = cy - s * 0.3 + lf * s * 0.3
            lw = math.sin(self.tick * 0.12 + i * 0.8) * 4
            pygame.draw.line(surf, c2, (lx, ly), (lx - 5, ly + s * 0.3 + lw), 1)
        pygame.draw.circle(surf, (255, 255, 255), (int(cx - s * 0.5), int(cy - s * 0.1)), max(2, s * 0.15))
        pygame.draw.circle(surf, (20, 20, 20), (int(cx - s * 0.5 + 1), int(cy - s * 0.1)), max(1, s * 0.08))

    def draw_squid(self, surf, name, cx, cy, size):
        s = size * 0.4
        c1, c2 = (200, 130, 255), (230, 180, 255)
        pygame.draw.ellipse(surf, c1, (int(cx - s * 0.8), int(cy - s * 1.2), int(s * 2), int(s * 1.5)))
        pygame.draw.ellipse(surf, c2, (int(cx - s * 0.5), int(cy - s * 1.1), int(s), int(s * 0.6)))
        for i in range(6):
            tx = int(cx - s * 0.8 + i * s * 0.32)
            w1 = math.sin(self.tick * 0.08 + i * 0.9) * 6
            w2 = math.sin(self.tick * 0.06 + i * 1.1) * 4
            pygame.draw.line(surf, c2, (tx, int(cy + s * 0.3)), (tx + int(w1), int(cy + s * 0.8)), 2)
            pygame.draw.line(surf, c1, (tx + int(w1), int(cy + s * 0.8)), (tx + int(w1 + w2 * 0.5), int(cy + s * 1.2)), 1)
        for ex in [cx - s * 0.25, cx + s * 0.25]:
            pygame.draw.circle(surf, (255, 255, 255), (int(ex), int(cy - s * 0.4)), max(2, int(s * 0.2)))
            pygame.draw.circle(surf, (20, 20, 20), (int(ex + 1), int(cy - s * 0.4)), max(1, int(s * 0.1)))
        for i in range(4):
            pygame.draw.circle(surf, (150, 80, 200), (int(cx - s * 0.5 + i * s * 0.3), int(cy - s * 0.7 + self._a(i) * 2)), 2)

    def draw_crab(self, surf, name, cx, cy, size):
        s = size * 0.4
        c1, c2 = (220, 80, 60), (255, 120, 90)
        snap = math.sin(self.tick * 0.1) * 3
        pygame.draw.ellipse(surf, c1, (int(cx - s * 1.3), int(cy - s * 0.6), int(s * 2.6), int(s * 1.2)))
        pygame.draw.ellipse(surf, c2, (int(cx - s * 0.9), int(cy - s * 0.4), int(s * 1.8), int(s * 0.8)))
        cpl = [(int(cx - s * 1.3), int(cy - s * 0.2)), (int(cx - s * 2.1), int(cy - s * 0.9 + snap)), (int(cx - s * 2.5), int(cy - s * 0.4)), (int(cx - s * 2.1), int(cy + snap)), (int(cx - s * 1.5), int(cy - s * 0.3))]
        cpr = [(int(cx + s * 1.3), int(cy - s * 0.2)), (int(cx + s * 2.1), int(cy - s * 0.9 - snap)), (int(cx + s * 2.5), int(cy - s * 0.4)), (int(cx + s * 2.1), int(cy - snap)), (int(cx + s * 1.5), int(cy - s * 0.3))]
        pygame.draw.polygon(surf, c2, cpl)
        pygame.draw.polygon(surf, c2, cpr)
        ew = math.sin(self.tick * 0.07) * 2
        for sx in [cx - s * 0.4, cx + s * 0.4]:
            pygame.draw.line(surf, c1, (int(sx), int(cy - s * 0.5)), (int(sx), int(cy - s)), 2)
            pygame.draw.circle(surf, (255, 255, 255), (int(sx), int(cy - s + ew)), max(2, int(s * 0.2)))
            pygame.draw.circle(surf, (20, 20, 20), (int(sx + 1), int(cy - s + ew)), max(1, int(s * 0.1)))
        for i in range(3):
            ly = cy + s * 0.2 + i * s * 0.2
            lx = cx - s * 1.0 + i * s * 0.5
            lw = math.sin(self.tick * 0.09 + i) * 2
            pygame.draw.line(surf, c2, (lx, ly), (lx - 5, ly + s * 0.3 + lw), 1)
            lx2 = cx + s * 1.0 - i * s * 0.5
            pygame.draw.line(surf, c2, (lx2, ly), (lx2 + 5, ly + s * 0.3 + lw), 1)

    def draw_minnow(self, surf, name, cx, cy, size):
        s = size * 0.5
        c1, c2 = (100, 180, 255), (150, 210, 255)
        a = self._a()
        dart = math.sin(self.tick * 0.1) * 2
        pygame.draw.ellipse(surf, c1, (int(cx - s * 1.2 + dart), int(cy - s * 0.4), int(s * 2.4), int(s * 0.8)))
        pygame.draw.ellipse(surf, c2, (int(cx - s * 0.8 + dart), int(cy - s * 0.3), int(s * 1.6), int(s * 0.5)))
        tw = math.sin(self.tick * 0.15) * 3
        tp = [(int(cx + s * 1.2 + dart), int(cy + dart * 0.5)), (int(cx + s * 2.0 + dart), int(cy - s * 0.5 + tw)), (int(cx + s * 2.0 + dart), int(cy + s * 0.5 + tw)), (int(cx + s * 1.2 + dart), int(cy + dart * 0.5))]
        pygame.draw.polygon(surf, c2, tp)
        pygame.draw.circle(surf, (255, 255, 255), (int(cx - s * 0.6 + dart), int(cy - s * 0.1)), max(2, int(s * 0.2)))
        pygame.draw.circle(surf, (10, 10, 30), (int(cx - s * 0.6 + dart + 1), int(cy - s * 0.1)), max(1, int(s * 0.1)))
        for i in range(3):
            sx = int(cx - s * 0.3 + i * s * 0.4 + math.sin(self.tick * 0.1 + i) * 2)
            sy = int(cy + math.sin(i * 2 + a) * s * 0.15)
            pygame.draw.circle(surf, (255, 255, 255, 80), (sx, sy), 1)

    def draw_lobster(self, surf, name, cx, cy, size):
        s = size * 0.45
        c1, c2 = (180, 60, 40), (220, 100, 70)
        a = self._a()
        pygame.draw.ellipse(surf, c1, (int(cx - s * 1.0), int(cy - s * 0.35), int(s * 2.0), int(s * 0.7)))
        pygame.draw.ellipse(surf, c2, (int(cx - s * 0.7), int(cy - s * 0.25), int(s * 1.4), int(s * 0.5)))
        for i in range(4):
            pygame.draw.circle(surf, c2, (int(cx - s * 0.5 + i * s * 0.35), int(cy + math.sin(i * 1.5 + a) * 2)), max(2, int(s * 0.1)))
        aw = math.sin(self.tick * 0.08) * 4
        pygame.draw.line(surf, c2, (int(cx - s * 0.8), int(cy - s * 0.3)), (int(cx - s * 1.3), int(cy - s * 0.8 + aw)), 1)
        pygame.draw.line(surf, c2, (int(cx + s * 0.8), int(cy - s * 0.3)), (int(cx + s * 1.3), int(cy - s * 0.8 - aw)), 1)
        tfw = math.sin(self.tick * 0.1) * 3
        tp = [(int(cx - s * 1.0), int(cy)), (int(cx - s * 1.6), int(cy - s * 0.5 + tfw)), (int(cx - s * 1.4), int(cy)), (int(cx - s * 1.6), int(cy + s * 0.5 + tfw))]
        pygame.draw.polygon(surf, c1, tp)
        claww = math.sin(self.tick * 0.09) * 2
        pygame.draw.ellipse(surf, c2, (int(cx - s * 1.5), int(cy - s * 0.6 + claww), int(s * 0.5), int(s * 0.5)))
        pygame.draw.ellipse(surf, c2, (int(cx + s * 1.0), int(cy - s * 0.6 - claww), int(s * 0.5), int(s * 0.5)))
        pygame.draw.circle(surf, (255, 255, 255), (int(cx - s * 0.6), int(cy - s * 0.2)), max(2, int(s * 0.12)))
        pygame.draw.circle(surf, (20, 20, 20), (int(cx - s * 0.6 + 1), int(cy - s * 0.2)), max(1, int(s * 0.06)))

    def draw_octopus(self, surf, name, cx, cy, size):
        s = size * 0.35
        c1, c2 = (220, 80, 200), (255, 150, 220)
        a = self._a()
        pygame.draw.ellipse(surf, c1, (int(cx - s), int(cy - s * 1.0), int(s * 2), int(s * 1.2)))
        pygame.draw.ellipse(surf, c2, (int(cx - s * 0.5), int(cy - s * 0.9), int(s), int(s * 0.5)))
        for i in range(8):
            angle = -math.pi * 0.8 + i * math.pi * 1.6 / 7
            ax = int(cx + math.cos(angle) * s * 0.8)
            ay = int(cy + s * 0.3)
            wave = math.sin(self.tick * 0.07 + i * 0.7) * 5
            ex = int(cx + math.cos(angle) * (s * 1.2 + wave))
            ey = int(ay + s * 0.6)
            pygame.draw.line(surf, c2, (ax, ay), (ex, ey), 2)
        for ex in [cx - s * 0.35, cx + s * 0.35]:
            pygame.draw.circle(surf, (255, 255, 255), (int(ex), int(cy - s * 0.3)), max(2, int(s * 0.2)))
            pygame.draw.circle(surf, (20, 20, 20), (int(ex + 1), int(cy - s * 0.3)), max(1, int(s * 0.1)))
        for i in range(6):
            sx = int(cx - s * 0.6 + i * s * 0.25)
            sy = int(cy - s * 0.6 + self._a(i) * 2)
            pygame.draw.circle(surf, (180, 50, 150), (sx, sy), max(1, int(s * 0.08)))

    def draw_krill(self, surf, name, cx, cy, size):
        s = size * 0.4
        c1, c2 = (100, 200, 150), (150, 230, 190)
        a = self._a()
        pygame.draw.ellipse(surf, c1, (int(cx - s * 0.6), int(cy - s * 0.25), int(s * 1.2), int(s * 0.5)))
        for i in range(3):
            pygame.draw.line(surf, c2, (int(cx + s * 0.6), int(cy + i * 2)), (int(cx + s * 1.0), int(cy + s * 0.2 + math.sin(self.tick * 0.1 + i) * 3)), 1)
        for i in range(3):
            pygame.draw.line(surf, c2, (int(cx - s * 0.6), int(cy - s * 0.1 + i * s * 0.1)), (int(cx - s * 1.0), int(cy - s * 0.1 + i * s * 0.1 + math.sin(self.tick * 0.08 + i) * 2)), 1)
        pygame.draw.circle(surf, (255, 255, 255), (int(cx - s * 0.3), int(cy - s * 0.05)), max(1, int(s * 0.1)))
        pygame.draw.circle(surf, (255, 255, 255), (int(cx - s * 0.3), int(cy + s * 0.05)), max(1, int(s * 0.1)))
        pygame.draw.circle(surf, (10, 10, 10), (int(cx - s * 0.3 + 1), int(cy - s * 0.05)), max(1, int(s * 0.05)))
        pygame.draw.circle(surf, (10, 10, 10), (int(cx - s * 0.3 + 1), int(cy + s * 0.05)), max(1, int(s * 0.05)))

    def draw_snail(self, surf, name, cx, cy, size):
        s = size * 0.4
        c1, c2 = (220, 200, 130), (255, 240, 180)
        a = self._a()
        pygame.draw.ellipse(surf, c1, (int(cx - s * 0.6), int(cy - s * 0.6), int(s * 1.2), int(s * 1.2)))
        pygame.draw.ellipse(surf, c2, (int(cx - s * 0.35), int(cy - s * 0.35), int(s * 0.7), int(s * 0.7)))
        pygame.draw.ellipse(surf, c1, (int(cx - s * 0.15), int(cy - s * 0.15), int(s * 0.3), int(s * 0.3)))
        pygame.draw.ellipse(surf, c2, (int(cx - s * 0.3), int(cy + s * 0.2), int(s * 0.8), int(s * 0.3)))
        tw = math.sin(self.tick * 0.07) * 2
        pygame.draw.line(surf, c2, (int(cx + s * 0.2), int(cy + s * 0.2)), (int(cx + s * 0.6), int(cy - s * 0.1 + tw)), 2)
        pygame.draw.line(surf, c2, (int(cx + s * 0.2), int(cy + s * 0.2)), (int(cx + s * 0.5), int(cy + tw)), 2)
        for ex, ey in [(cx + s * 0.5, cy - s * 0.1 + tw), (cx + s * 0.45, cy + tw)]:
            pygame.draw.circle(surf, (255, 255, 255), (int(ex), int(ey)), max(1, int(s * 0.08)))
            pygame.draw.circle(surf, (20, 20, 20), (int(ex + 1), int(ey)), max(1, int(s * 0.04)))

    def draw_mudskipper(self, surf, name, cx, cy, size):
        s = size * 0.5
        c1, c2 = (120, 160, 80), (160, 200, 120)
        a = self._a()
        pygame.draw.ellipse(surf, c1, (int(cx - s * 0.8), int(cy - s * 0.35), int(s * 1.6), int(s * 0.7)))
        pygame.draw.ellipse(surf, c2, (int(cx - s * 0.5), int(cy - s * 0.25), int(s * 1.0), int(s * 0.5)))
        ew = math.sin(self.tick * 0.06) * 2
        for ex in [cx - s * 0.3, cx + s * 0.2]:
            pygame.draw.circle(surf, (255, 255, 255), (int(ex), int(cy - s * 0.5 + ew)), max(2, int(s * 0.25)))
            pygame.draw.circle(surf, (10, 10, 10), (int(ex), int(cy - s * 0.5 + ew)), max(1, int(s * 0.13)))
        fw = math.sin(self.tick * 0.1) * 3
        pygame.draw.polygon(surf, c2, [(int(cx), int(cy - s * 0.35)), (int(cx - s * 0.3), int(cy - s * 0.7 + fw)), (int(cx + s * 0.2), int(cy - s * 0.35))])
        for i in range(2):
            lx = int(cx - s * 0.3 + i * s * 0.6)
            lw = math.sin(self.tick * 0.08 + i * 1.5) * 3
            pygame.draw.line(surf, c2, (lx, int(cy + s * 0.3)), (lx + int(lw), int(cy + s * 0.6)), 2)
            pygame.draw.ellipse(surf, c2, (lx + int(lw) - 3, int(cy + s * 0.55), 6, 3))

    def draw_barnacle(self, surf, name, cx, cy, size):
        s = size * 0.4
        c1, c2 = (200, 200, 180), (230, 230, 210)
        a = self._a()
        pygame.draw.polygon(surf, c1, [(int(cx), int(cy - s)), (int(cx - s * 0.8), int(cy + s * 0.3)), (int(cx + s * 0.8), int(cy + s * 0.3))])
        pygame.draw.polygon(surf, c2, [(int(cx), int(cy - s * 0.7)), (int(cx - s * 0.5), int(cy + s * 0.15)), (int(cx + s * 0.5), int(cy + s * 0.15))])
        for i in range(3):
            r = int(s * 0.25 * (i + 1))
            pts = []
            for j in range(6):
                ang = math.pi * 0.5 + j * math.pi / 3
                pts.append((int(cx + math.cos(ang) * r), int(cy - s * 0.7 + math.sin(ang) * r * 0.6)))
            pygame.draw.polygon(surf, c1, pts)
        op = math.sin(self.tick * 0.05) * 1
        pygame.draw.polygon(surf, (180, 180, 160), [(int(cx - 2), int(cy)), (int(cx + 2), int(cy)), (int(cx + 1), int(cy + s * 0.2 + op)), (int(cx - 1), int(cy + s * 0.2 + op))])

    def draw_worm(self, surf, name, cx, cy, size):
        s = size * 0.4
        c1, c2 = (200, 120, 100), (230, 160, 140)
        pts = []
        for i in range(20):
            frac = i / 19
            wx = int(cx - s * 0.5 + frac * s)
            wy = int(cy + math.sin(self.tick * 0.08 + frac * 4) * s * 0.4 * (1 - frac * 0.3))
            pts.append((wx, wy))
        pygame.draw.lines(surf, c1, False, pts, max(1, int(s * 0.3)))
        pygame.draw.lines(surf, c2, False, pts, max(1, int(s * 0.15)))
        pygame.draw.circle(surf, c1, (int(pts[0][0]), int(pts[0][1])), max(2, int(s * 0.2)))
        for ex in [-1, 1]:
            pygame.draw.circle(surf, (255, 255, 255), (int(pts[0][0] + ex * 1), int(pts[0][1] - 1)), max(1, int(s * 0.06)))
            pygame.draw.circle(surf, (10, 10, 10), (int(pts[0][0] + ex * 1), int(pts[0][1] - 1)), max(1, int(s * 0.03)))

    def draw_midge(self, surf, name, cx, cy, size):
        s = size * 0.35
        c1, c2 = (80, 120, 200), (130, 170, 240)
        wing_angle = math.sin(self.tick * 0.2) * 0.5
        pygame.draw.ellipse(surf, c1, (int(cx - s * 0.4), int(cy - s * 0.2), int(s * 0.8), int(s * 0.4)))
        pygame.draw.ellipse(surf, c2, (int(cx - s * 0.8), int(cy - s * 0.5 + math.sin(wing_angle) * 3), int(s * 0.5), int(s * 0.3)))
        pygame.draw.ellipse(surf, c2, (int(cx + s * 0.3), int(cy - s * 0.5 + math.sin(wing_angle + 1) * 3), int(s * 0.5), int(s * 0.3)))
        pygame.draw.circle(surf, (255, 255, 255), (int(cx + s * 0.2), int(cy - s * 0.05)), max(1, int(s * 0.15)))
        pygame.draw.circle(surf, (10, 10, 10), (int(cx + s * 0.21), int(cy - s * 0.05)), max(1, int(s * 0.08)))

    def draw_fish(self, surf, cx, cy, size, flip_h=False, fin_damaged=False, sad_face=False, open_mouth=0):
        """Draw the player firefish goby with optional damaged fin and sad face."""
        t = self.tick * 0.05
        bob = cy + 8 * math.sin(t)
        x, y = int(cx), int(bob)
        cs = (255, 200, 40) if flip_h else (240, 80, 30)
        ce = (240, 80, 30) if flip_h else (255, 200, 40)
        pygame.draw.ellipse(surf, cs, (x - int(size*1.5), y - int(size*0.45), size*3, size*0.9))
        for i in range(int(size*3)):
            ratio = i / max(1, size*3)
            r = int(cs[0] - ratio * (cs[0] - ce[0]))
            g = int(cs[1] - ratio * (cs[1] - ce[1]))
            b = int(cs[2] - ratio * (cs[2] - ce[2]))
            pygame.draw.line(surf, (r, g, b), (x - int(size*1.5) + i, y - int(size*0.4)), (x - int(size*1.5) + i, y + int(size*0.35)))
        fw = math.sin(t * 2) * 4
        if not fin_damaged:
            # Firefish-like dorsal fin: a tall, swept, very sharp triangle.
            # The apex is high and the trailing edge is long so the fin reads
            # more like a shark fin silhouette than a rounded crest.
            sway = int(2 * math.sin(t * 2))
            dp = [
                (x - int(size * 0.95), y - int(size * 0.39)),
                (x - int(size * 0.14) + sway, y - int(size * 1.46)),
                (x - int(size * 0.725), y - int(size * 0.45)),
            ]
            pygame.draw.polygon(surf, (255, 100, 50), dp)
        vp = [(x - int(size*0.4), y + int(size*0.45))]
        for i in range(6):
            fx = x - int(size*0.2) + i * (size*0.14)
            wave = 3 * math.sin(i / 6 * math.pi) - fw * 0.3 * (i / 6)
            vp.append((fx, y + int(size*0.66) + int(wave * 0.5)))
        vp.append((x + int(size*0.18), y + int(size*0.45)))
        pygame.draw.polygon(surf, (240, 90, 40), vp)
        tw = math.sin(t * 3) * 3
        tbx = x + int(size*1.3) if not flip_h else x - int(size*1.3)
        tp = [(tbx, y)]
        for i in range(7):
            angle = -0.9 + i * 0.3
            tx = tbx + int(size * 0.7 * math.cos(angle))
            ty = y + int(size * 0.6 * math.sin(angle)) + int(tw * math.sin(angle + t))
            tp.append((tx, ty))
        pygame.draw.polygon(surf, (230, 70, 30), tp)
        ey = y - int(size*0.12)
        pygame.draw.circle(surf, (255, 255, 255), (x - int(size*1.0), ey), int(size*0.22))
        pygame.draw.circle(surf, (15, 15, 30), (x - int(size*1.0) + 1, ey), int(size*0.13))
        pygame.draw.circle(surf, (255, 255, 255), (x - int(size*1.0) + 3, ey - 2), 2)
        if open_mouth > 0:
            # Inset the open mouth into the head rather than floating left of it.
            mx = x - int(size * 1.18)
            mouth_open = open_mouth * size * 0.15
            pygame.draw.polygon(surf, (180, 30, 20), [
                (mx, y - 2),
                (mx - int(size*0.3) - int(mouth_open), y - int(size*0.2) - int(mouth_open)),
                (mx - int(size*0.3) - int(mouth_open), y + int(size*0.2) + int(mouth_open)),
                (mx, y + 2)
            ])
        elif sad_face:
            mx = x - int(size*1.4) if flip_h else x - int(size*1.4)
            pygame.draw.arc(surf, (180, 60, 20), (mx - 5, y + 1, 10, 6), 3.5, 6.1, 2)
        else:
            mx = x - int(size*1.4) if flip_h else x - int(size*1.4)
            pygame.draw.arc(surf, (180, 60, 20), (mx - 5, y - 3, 10, 6), 0.3, 2.8, 2)
        for i in range(8):
            sx = x - int(size*0.2) + i * int(size*0.3)
            sy = y + int(math.sin(i * 1.8) * size * 0.12)
            pygame.draw.circle(surf, (40, 80, 240), (sx, sy), max(2, int(size*0.1)))
        self._draw_escape_fin(surf, x, y, size, flip_h, fin_damaged)

    def _draw_escape_fin(self, surf, x, y, size, flip_h, damaged):
        """Draw the escape fin on the side of the fish. Damaged = ragged thread look."""
        if flip_h:
            fx = x - int(size * 1.1)
            dir = -1
        else:
            fx = x - int(size * 1.1)
            dir = -1
        fy = y - int(size * 0.15)
        fsize = int(size * 0.5)
        if not damaged:
            # Healthy fin: smooth, flowing filament
            wave = math.sin(self.tick * 0.08) * 3
            pygame.draw.line(surf, (255, 180, 60), (fx, fy), (fx + dir * fsize, fy - fsize // 2 + wave), 2)
            pygame.draw.line(surf, (255, 200, 80), (fx, fy), (fx + dir * fsize, fy - fsize // 3), 1)
            tip_x = fx + dir * fsize
            tip_y = fy - fsize // 2 + wave
            pygame.draw.circle(surf, (255, 210, 100), (int(tip_x), int(tip_y)), 2)
        else:
            # Damaged fin: ragged, torn, irregular thread (slow wave)
            slow_wave = math.sin(self.tick * 0.03) * 2
            segments = [(fx, fy)]
            for i in range(5):
                t = i / 4.0
                jx = fx + dir * (fsize // 4) * i
                jy = fy - (fsize // 2) * t + slow_wave * t
                segments.append((int(jx), int(jy)))
            pygame.draw.lines(surf, (180, 120, 60), False, segments, 3)
            # Frayed bits
            for i in range(3):
                sx = fx + dir * (fsize // 4 + i * (fsize // 6))
                sy = fy - (fsize // 5) * (i + 1) + slow_wave * 0.5
                ex = sx + dir * 4
                ey = sy + 3
                pygame.draw.line(surf, (160, 100, 50), (sx, sy), (ex, ey), 3)
            # Small stub at base
            stub_end = (int(fx + dir * fsize // 3), int(fy - fsize // 5))
            pygame.draw.line(surf, (200, 140, 70), (fx, fy), stub_end, 3)


def lerp_color(c1, c2, t):
    return (int(c1[0] + (c2[0] - c1[0]) * t),
            int(c1[1] + (c2[1] - c1[1]) * t),
            int(c1[2] + (c2[2] - c1[2]) * t))


# ── game states ────────────────────────────────────────────────────────

class SplashState:
    def __init__(self):
        self.tick = 0
        # Use the same fish renderer as the daytime eating animation.
        self.fish_renderer = CritterRenderer()

    def handle_event(self, event):
        if event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
            return True
        return False

    def draw(self, surf):
        self.tick += 1
        surf.fill((10, 20, 60))

        # Background waves (no alpha)
        for i in range(20):
            y = (i * 35 + self.tick * 0.5) % (H + 40) - 20
            alpha_val = max(0, 30 - i)
            pygame.draw.line(surf, (30, 60, 120), (0, y), (W, y), 2)

        # Bubbles (no alpha)
        for i in range(15):
            bx = (i * 61 + self.tick * 0.8) % W
            by = H - ((i * 43 + self.tick * 1.2) % (H + 40))
            bs = 2 + (i % 5)
            ba = 0.3 + 0.7 * ((math.sin(self.tick * 0.05 + i) + 1) / 2)
            brightness = min(255, max(0, int(140 + 100 * ba)))
            c = (brightness, min(255, brightness + 15), min(255, brightness + 25))
            pygame.draw.circle(surf, c, (int(bx), int(by)), bs, 1)
            highlight = min(255, brightness + 40)
            pygame.draw.circle(surf, (highlight, highlight, highlight), (int(bx - 1), int(by - 1)), max(1, bs // 3))

        title_surf = F52.render("EATER QUEST", True, (255, 200, 80))
        title_surf.set_alpha(255)
        surf.blit(title_surf, title_surf.get_rect(center=(W//2, 76)))

        sub_surf = F28.render("A Firefish Goby Survival Game", True, (150, 200, 255))
        surf.blit(sub_surf, sub_surf.get_rect(center=(W//2, 166)))

        self.fish_renderer.tick = self.tick
        self.fish_renderer.draw_fish(surf, W//2 - 160, H//2 - 30, 44, flip_h=False)
        self.fish_renderer.draw_fish(surf, W//2 + 160, H//2 - 10, 44, flip_h=True)

        egg_x, egg_y = W//2, H//2 + 20
        ec = (255, 240, 210) if self.tick % 40 < 20 else (255, 245, 220)
        pygame.draw.ellipse(surf, ec, (egg_x - 30, egg_y - 40, 60, 80))

        lines = ["Roll dice. Hatch, eat, grow. Reach 4 inches to win!", "Click ENTER or click to continue..."]
        for i, line in enumerate(lines):
            color = (100, 255, 100) if i == 1 else (200, 220, 255)
            draw_text(surf, line, (W//2, H - 116 + i * 58), font=F20, color=color)


class EggState:
    def __init__(self):
        self.game = None  # type: ignore
        self.days = 0
        self.result = None
        self.tick = 0
        self.rolling = False
        self.roll_anim = 0
        self.d1 = 1
        self.d2 = 1
        self.d1_target = 1
        self.d2_target = 1
        self.show_result = False
        self.hatch_cracks = 0
        self.anim_crack = 0
        self.highlighted = False
        self.awaiting_ack = False
        self.hatch_wait = 0

    def start(self):
        self.days = 0
        self.result = None
        self.tick = 0
        self.rolling = False
        self.roll_anim = 0
        self.d1 = 1
        self.d2 = 1
        self.show_result = False
        self.hatch_cracks = 0
        self.anim_crack = 0
        self.awaiting_ack = False
        self.hatch_wait = 0
        self.highlighted = False

    def update(self):
        if self.result:
            if self.result == "hatched":
                self.hatch_wait += 1
            return
        self.tick += 1
        if self.rolling:
            self.roll_anim += 1
            if self.roll_anim > 30:
                self.d1 = random.randint(1, 10)
                self.d2 = random.randint(1, 10)
                self.d1_target = self.d1
                self.d2_target = self.d2
                self.rolling = False
                self.show_result = True
                if self.d1 + self.d2 >= 12:
                    self.result = "hatched"
                    if self.game:
                        self.game.play_hatch()
                else:
                    self.days += 1
                    self.anim_crack = self.days
                    if self.days >= 3:
                        self.result = "eaten"
                        self.awaiting_ack = True

    def handle_event(self, event):
        if self.result:
            if self.result == "eaten" and self.awaiting_ack:
                return False
            return False
        if self.show_result:
            if self.result == "eaten":
                return event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN)
            if event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                self.show_result = False
                self.d1_target = random.randint(1, 10)
                self.d2_target = random.randint(1, 10)
                return True
            return False
        if event.type == pygame.MOUSEMOTION:
            mx, my = event.pos
            self.highlighted = False
            btn = pygame.Rect(W//2 - 145, H - 112, 290, 100)
            if btn.collidepoint(mx, my) and not self.result:
                self.highlighted = True
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            btn = pygame.Rect(W//2 - 145, H - 112, 290, 100)
            if btn.collidepoint(mx, my) and not self.result:
                self.d1_target = random.randint(1, 10)
                self.d2_target = random.randint(1, 10)
                self.rolling = True
                self.roll_anim = 0
                if self.game:
                    self.game.play_dice()
                return True
        return False

    def draw_die(self, surf, x, y, value, label, sides=10, rolling=False):
        sz = 52.5
        pts = []
        for i in range(sides):
            angle = math.pi/2 + (2*math.pi*i/sides) - (math.pi/sides)
            px = x + sz * math.cos(angle)
            py = y + sz * math.sin(angle)
            if rolling:
                px += (self.tick % 6) * 3 * ((-1) ** i)
                py += (self.tick % 6) * 3 * ((-1) ** (i+1)) * 0.5
            pts.append((px, py))
        color = (255, 80, 60) if rolling else (60, 180, 255)
        pygame.draw.polygon(surf, color, pts)
        shown = F52.render(str(value), True, (0, 0, 0))
        if shown.get_width() > sz * 1.4:
            scale = (sz * 1.4) / shown.get_width()
            shown = pygame.transform.smoothscale(shown, (max(1, int(shown.get_width() * scale)), max(1, int(shown.get_height() * scale))))
        surf.blit(shown, shown.get_rect(center=(x, y)))
        draw_text(surf, label, (x, y + sz + 12), (200,220,255), F16)

    def draw_egg(self, surf, cx, cy):
        twitch = self.anim_crack * 3
        t = self.tick * 0.15
        tx = math.sin(t * 3.7) * twitch
        ty = math.cos(t * 2.3) * twitch * 0.6
        ec = (255, 240, 210) if self.tick % 20 < 10 else (255, 245, 220)
        pygame.draw.ellipse(surf, (50, 40, 30), (cx-38+tx, cy-50+ty, 76, 105))
        pygame.draw.ellipse(surf, ec, (cx-40+tx, cy-55+ty, 80, 110))
        pygame.draw.ellipse(surf, (255, 255, 250), (cx-25+tx, cy-45+ty, 25, 35))
        if self.anim_crack > 0:
            nc = self.anim_crack * 2
            for i in range(nc):
                angle = (i * 73 + self.tick * 0.5) * math.pi / 180
                r1, r2 = 10 + i * 5, 25 + i * 4
                x1 = cx + tx + r1 * math.cos(angle)
                y1 = cy + ty + r1 * math.sin(angle) * 1.3
                x2 = cx + tx + r2 * math.cos(angle)
                y2 = cy + ty + r2 * math.sin(angle) * 1.3
                pygame.draw.line(surf, (140, 120, 90), (x1, y1), (x2, y2), 2)

    def draw(self, surf):
        surf.fill(BG_EGG)
        cx, cy = W//2, H//2 - 10
        draw_text(surf, "EGG PHASE", (cx, 65), font=F40)
        draw_text(surf, f"Day {self.days + 1} / 3", (cx, 132), font=F24)
        draw_text(surf, "Click to roll 2d10 - need 12+ to hatch!", (cx, 186), font=F18)
        # Render the existing egg artwork at 150% size, centered just 36 pixels above its original position.
        # Keeping this on a transparent intermediate surface scales the shell,
        # highlight and animated cracks together without changing their motion.
        egg_layer = pygame.Surface((180, 180), pygame.SRCALPHA)
        self.draw_egg(egg_layer, 90, 90)
        egg_layer = pygame.transform.smoothscale(egg_layer, (270, 270))
        egg_center_y = cy + 4
        surf.blit(egg_layer, egg_layer.get_rect(center=(cx, egg_center_y)))
        if self.show_result:
            total = self.d1 + self.d2
            draw_text(surf, f"Rolled: {self.d1} + {self.d2} = {total}", (cx, cy + 130), font=F28)
            if self.result == "hatched":
                draw_text(surf, "You hatched!", (cx, cy + 170), (100, 255, 100), font=F32)
            elif self.result == "eaten":
                draw_text(surf, "You took too long to hatch,", (cx, cy + 160), (255, 100, 100), font=F24)
                draw_text(surf, "a baby minnow ate your egg.", (cx, cy + 195), (255, 100, 100), font=F24)
                draw_text(surf, "Game over!", (cx, cy + 235), (255, 50, 50), font=F32)
            else:
                draw_text(surf, "Not enough...", (cx, cy + 170), (255, 200, 100), font=F28)
                draw_text(surf, f"[Click to continue (Day {self.days + 1}/3)]", (cx, H - 40), font=F20)
        elif self.rolling:
            d1d = random.randint(1, 10)
            d2d = random.randint(1, 10)
            self.draw_die(surf, cx - 60, cy + 110, d1d, "d10", 10, True)
            draw_text(surf, "+", (cx, cy + 110), font=F32)
            self.draw_die(surf, cx + 60, cy + 110, d2d, "d10", 10, True)
        elif not self.result:
            self.draw_die(surf, cx - 60, cy + 110, "?", "d10", 10, False)
            draw_text(surf, "+", (cx, cy + 110), font=F32)
            self.draw_die(surf, cx + 60, cy + 110, "?", "d10", 10, False)
            roll_rect = pygame.Rect(W//2 - 145, H - 112, 290, 100)
            draw_btn_glow(surf, "Roll Dice", roll_rect, self.highlighted, not self.result, self.tick)




DAY_CARD_CENTERS = (190, 540, 890)
DAY_CARD_CY = 219
DAY_CARD_W, DAY_CARD_H = 288, 186
DAY_EATER_CY = 449
DAY_ROLL_RECT = (260, 615, 270, 95)
DAY_PLAY_RECT = (555, 615, 475, 95)

class DayState:
    """Day phase: 3 critters with dice below, Eater with dice below, boosts on lower left."""

    def __init__(self, game):
        self.game = game
        self.critter_data = []
        self.phase = "choice"
        self.highlighted_card = -1
        self.highlighted_boost = -1
        self.tick = 0
        self.chase_result = None
        self.chase_phase = ""
        self.chase_tick = 0
        self.eaten = 0
        self.all_rolled = False
        self.eater_rolled = False
        self.critter_rolled = [False, False, False]
        self.boosts_available = []
        self.boost_used = []
        self.boost_values = []
        self.can_roll = True
        self.highlighted_roll = False
        self.highlighted_play = False

    def start(self, critters, size, boosts):
        self.critter_data = []
        self.phase = "choice"
        self.highlighted_card = -1
        self.highlighted_boost = -1
        self.tick = 0
        self.cooldown = 30
        self.chase_result = None
        self.chase_phase = ""
        self.chase_tick = 0
        self.eaten = 0
        self.all_rolled = False
        self.eater_rolled = False
        self.critter_rolled = [False, False, False]
        self.boosts_available = list(boosts)
        self.boost_used = list(self.game._shared_boost_used[:len(boosts)])
        self.boost_values = list(boosts)
        self.can_roll = True
        self.highlighted_roll = False
        self.highlighted_play = False
        self.pending_boost_mult = 0
        self.pending_boost_val = 0
        self._result_processed = False
        for i, name in enumerate(critters):
            speed = Fraction(random.randint(1, 12) + random.randint(1, 12))
            shade = random.uniform(0.75, 1.25)
            base = CARD_COLORS[i]
            color_variation = (
                min(255, int(base[0] * shade)),
                min(255, int(base[1] * shade)),
                min(255, int(base[2] * shade)),
            )
            size_var = random.uniform(0.85, 1.15)
            self.critter_data.append({
                "name": name,
                "speed": speed,
                "speed_display": "?",
                "color": color_variation,
                "base_color": base,
                "type": get_critter_type(name),
                "caught": None,
                "size_var": size_var,
            })
        self.eater_speed = 0
        self.eater_speed_display = "?"
        self.roll_anim_tick = 0
        self.boost_anim_tick = 0
        self.pending_boost_val = 0
        self.pending_boost_mult = 0

    def _tint_surface(self, surface, base_color, alpha=100):
        tint = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        tint.fill((*base_color, alpha))
        surface.blit(tint, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)

    def _draw_critter_card(self, surf, cx, cy, data, rolling=False, draw_sprite=True):
        card_w, card_h = DAY_CARD_W, DAY_CARD_H
        x, y = cx - card_w // 2, cy - 100
        border = (100, 200, 255) if (self.highlighted_card >= 0 and self.highlighted_card == self.critter_data.index(data) and data["caught"] is None) else (80, 100, 140)
        pygame.draw.rect(surf, border, (x, y, card_w, card_h), 3, border_radius=8)
        name_font = F12 if len(data["name"]) > 18 else F14
        name_col = (255, 255, 200) if border == (100, 200, 255) else (220, 220, 220)
        name_surf = _fit_font_render(name_font, data["name"], name_col, card_w - 20, 36)
        surf.blit(name_surf, (x + 10, y + 11))
        if data["caught"] == "caught":
            draw_text(surf, "Eaten!", (cx, y + card_h // 2 - 40), font=F32, color=(100, 255, 100))
            die_x, die_y = cx, y + card_h - 29
            die_color = data["base_color"]
            draw_die(surf, die_x, die_y, data["speed_display"], 10, die_color)
        elif data["caught"] == "escaped":
            die_x, die_y = cx, y + card_h - 29
            draw_die(surf, die_x, die_y, data["speed_display"], 10, data["base_color"])
            # Text is drawn by the final overlay pass so nothing covers it.
        else:
            draw_text_left(surf, "Speed:", (x + 10, y + card_h - 29), (200, 200, 200), F14)
            die_x, die_y = cx, y + card_h - 29
            if rolling:
                draw_die(surf, die_x, die_y, "?", 10, (255, 80, 60), True)
            else:
                die_color = data["base_color"]
                draw_die(surf, die_x, die_y, data["speed_display"], 10, die_color)
            if not draw_sprite:
                return
            sprite_size = int(75 * data.get("size_var", 1.0))
            sprite_surf = pygame.Surface((sprite_size * 2, sprite_size * 2), pygame.SRCALPHA)
            self.game.critter_renderer.draw(sprite_surf, data["type"], sprite_size, sprite_size, sprite_size)
            sprite_x, sprite_y = cx - sprite_size, y + 4
            surf.blit(sprite_surf, (sprite_x, sprite_y))

    def _draw_critter_card_eaten(self, surf, cx, cy, data):
        card_w, card_h = DAY_CARD_W, DAY_CARD_H
        x, y = cx - card_w // 2, cy - 100
        pygame.draw.rect(surf, (100, 255, 100), (x, y, card_w, card_h), 3, border_radius=8)
        name_surf = _fit_font_render(F14, data["name"], (255, 255, 200), card_w - 20, 36)
        surf.blit(name_surf, (x + 10, y + 11))
        draw_text(surf, "Eaten!", (cx, y + card_h // 2 - 40), (100, 255, 100), F32)
        die_x, die_y = cx, y + card_h - 29
        draw_die(surf, die_x, die_y, str(data["speed"]), 16, data["base_color"])

    def _draw_eater_card(self, surf, cx, cy, sad=False, rolling=False):
        card_w, card_h = 315, 180
        x, y = cx - card_w // 2, cy - card_h // 2
        border = (255, 180, 40)
        pygame.draw.rect(surf, (45, 35, 25), (x, y, card_w, card_h), border_radius=8)
        pygame.draw.rect(surf, border, (x, y, card_w, card_h), 2, border_radius=8)
        fs = fish_display_size(self.game.size) * 2
        fw = int(fs * 3.5)
        fh = int(fs * 2.6)
        fish_surf = pygame.Surface((fw, fh), pygame.SRCALPHA)
        self.game.critter_renderer.draw_fish(fish_surf, int(fs * 1.5), int(fs * 1.3), fs, flip_h=False, fin_damaged=self.game.fin_damaged, sad_face=sad)
        draw_text_left(surf, "EATER", (x + 10, y + 8), (255, 200, 100), F20)
        sprite_x, sprite_y = cx - fw // 2, y + 20
        surf.blit(fish_surf, (sprite_x, sprite_y))
        die_x, die_y = cx, cy + card_h // 2 + 23
        if rolling:
            draw_die(surf, die_x, die_y, "?", 10, (255, 80, 60), True)
        else:
            die_color = (255, 180, 60) if self.eater_rolled and self.eater_speed > 5 else (255, 120, 60)
            draw_die(surf, die_x, die_y, self.eater_speed_display, 10, die_color)

    def _draw_boosts(self, surf):
        x = 26
        for i, b in enumerate(self.boost_values):
            cy = H - 68 - i * 78
            card_w, card_h = 112, 70
            cx = x + card_w // 2
            is_used = self.boost_used[i] or self.can_roll
            is_highlighted = self.highlighted_boost == i
            if is_used:
                pygame.draw.rect(surf, (30, 50, 35), (x, cy - card_h // 2, card_w, card_h), border_radius=6)
                draw_text(surf, "x" + str(b), (cx, cy), (100, 100, 100), F18)
            else:
                border = (100, 255, 100) if is_highlighted else (80, 180, 80)
                pygame.draw.rect(surf, (30, 50, 35), (x, cy - card_h // 2, card_w, card_h), border_radius=6)
                pygame.draw.rect(surf, border, (x, cy - card_h // 2, card_w, card_h), 2, border_radius=6)
                draw_text(surf, "x" + str(b), (cx, cy), (100, 255, 150), F18)
        if self.boosts_available and self.chase_phase != "result":
            boost_cx = x + 112 // 2
            top_cy = H - 68 - (len(self.boost_values) - 1) * 78
            draw_text(surf, "Use Speed", (boost_cx, top_cy - 95), (200, 255, 200), F24)
            draw_text(surf, "Boost!", (boost_cx, top_cy - 52), (200, 255, 200), F24)

    def _draw_day_boost_die(self, surf, die_x, die_y, tick):
        if self.pending_boost_mult > 0:
            if tick < 20:
                scale = 1 + tick / 20 * 1.0
                sz = int(42 * scale)
                pts = [
                    (die_x + sz * math.cos(math.pi/2 + 2*math.pi*i/10 - math.pi/10),
                     die_y + sz * math.sin(math.pi/2 + 2*math.pi*i/10 - math.pi/10))
                    for i in range(10)
                ]
                glow = 40 * math.sin(tick * 0.15)
                boost_color = (min(255, 255 + int(glow)), 200, 50)
                pygame.draw.polygon(surf, boost_color, pts)
                draw_text(surf, str(self.eater_speed_display), (die_x, die_y), (255, 220, 80), F36)
            elif tick < 40:
                shrink_t = (tick - 20) / 20.0
                scale = 2.0 - shrink_t * 1.0
                sz = int(42 * scale)
                pts = [
                    (die_x + sz * math.cos(math.pi/2 + 2*math.pi*i/10 - math.pi/10),
                     die_y + sz * math.sin(math.pi/2 + 2*math.pi*i/10 - math.pi/10))
                    for i in range(10)
                ]
                glow = 40 * math.sin(tick * 0.15)
                boost_color = (min(255, 255 + int(glow)), 200, 50)
                pygame.draw.polygon(surf, boost_color, pts)
                draw_text(surf, str(self.eater_speed_display), (die_x, die_y), (255, 220, 80), F36)
            else:
                display = fmt_speed(self.pending_boost_val)
                die_color = (255, 180, 60) if self.eater_rolled and self.eater_speed > 5 else (255, 120, 60)
                draw_die(surf, die_x, die_y, display, 10, die_color)
                draw_text(surf, f"x{self.pending_boost_mult}", (die_x, die_y + 40), font=F20, color=(255, 220, 80))
        else:
            if tick < 20:
                scale = 1 + tick / 20
                sz = int(42 * scale)
                pts = [
                    (die_x + sz * math.cos(math.pi/2 + 2*math.pi*i/10 - math.pi/10),
                     die_y + sz * math.sin(math.pi/2 + 2*math.pi*i/10 - math.pi/10))
                    for i in range(10)
                ]
                glow = 40 * math.sin(tick * 0.15)
                boost_color = (min(255, 255 + int(glow)), 200, 50)
                pygame.draw.polygon(surf, boost_color, pts)
                draw_text(surf, str(self.eater_speed_display), (die_x, die_y), (255, 220, 80), F36)
            elif tick < 40:
                shrink_t = (tick - 20) / 20.0
                scale = 2.0 - shrink_t * 1.0
                sz = int(42 * scale)
                pts = [
                    (die_x + sz * math.cos(math.pi/2 + 2*math.pi*i/10 - math.pi/10),
                     die_y + sz * math.sin(math.pi/2 + 2*math.pi*i/10 - math.pi/10))
                    for i in range(10)
                ]
                glow = 40 * math.sin(tick * 0.15)
                boost_color = (min(255, 255 + int(glow)), 200, 50)
                pygame.draw.polygon(surf, boost_color, pts)
                draw_text(surf, str(self.eater_speed_display), (die_x, die_y), (255, 220, 80), F36)
            else:
                display = str(self.eater_speed_display)
                die_color = (255, 180, 60) if self.eater_rolled and self.eater_speed > 5 else (255, 120, 60)
                draw_die(surf, die_x, die_y, display, 10, die_color)

    def _roll_dice(self):
        """Roll Eater and all critter dice."""
        if self.eater_rolled:
            self.eater_speed_display = fmt_speed(self.eater_speed)
        else:
            self.eater_speed = Fraction(random.randint(1, 8) + random.randint(1, 8))
            if self.pending_boost_mult > 0:
                self.eater_speed *= self.pending_boost_mult
                self.pending_boost_val = self.eater_speed
            self.eater_speed_display = fmt_speed(self.eater_speed)
        self.eater_rolled = True
        for i in range(3):
            if self.critter_data[i]["caught"] is None:
                self.critter_data[i]["speed_display"] = fmt_speed(self.critter_data[i]["speed"])
                self.critter_rolled[i] = True
        self.all_rolled = True

    def _apply_boost(self, boost_val):
        """Store the speed boost multiplier for next chase."""
        self.pending_boost_mult = boost_val
        if self.eater_rolled and self.eater_speed > 0:
            self.eater_speed *= boost_val
            self.eater_speed_display = fmt_speed(self.eater_speed)
            self.pending_boost_val = self.eater_speed
            self.pending_boost_mult = 0
        else:
            self.pending_boost_val = boost_val
        self.chase_phase = "boost_anim"
        if self.chase_result:
            self.chase_result["used_boost"] = True
            self.chase_result["boost_val"] = boost_val
        self.chase_tick = 0
        self._result_processed = False
        self.game.play_boost()

    def _draw_chase_anim(self, surf):
        tick = self.chase_tick
        phase = self.chase_phase
        bg = self.game.background
        bg.draw_open_ocean(surf) if self.game.habitat_size < 1 else \
        bg.draw_mangrove(surf) if self.game.habitat_size < 2 else \
        bg.draw_kelp_forest(surf) if self.game.habitat_size < 3 else \
        bg.draw_coral_reef(surf)
        if phase == "roll_anim":
            for cd in self.critter_data:
                self._draw_critter_card(surf, DAY_CARD_CENTERS[self.critter_data.index(cd)], DAY_CARD_CY, cd, rolling=True)
            self._draw_eater_card(surf, W // 2, DAY_EATER_CY, sad=self.game.hungry, rolling=True)
            self._draw_boosts(surf)
            draw_text(surf, "Rolling...", (W // 2, H // 2 - 60), font=F28, color=(255, 255, 150))
            if tick > 30:
                self._roll_dice()
                self.chase_phase = "show_roll"
                self.chase_tick = 0
                self.game.play_dice()
            return
        if phase == "show_roll":
            draw_text(surf, get_zone_name(self.game.habitat_size), (W // 2, 14), font=F16, color=(255, 255, 200))
            self.game.progress_bar.draw(surf, self.game.size, W - 220, 10, 200)
            draw_text(surf, "Eater meets three tiny critters that would like to be friends.", (W // 2, 51), font=F18, color=(255, 220, 200))
            draw_text(surf, "Click on them to eat them.", (W // 2, 89), font=F20, color=(255, 220, 200))
            for cd in self.critter_data:
                self._draw_critter_card(surf, DAY_CARD_CENTERS[self.critter_data.index(cd)], DAY_CARD_CY, cd)
            self._draw_eater_card(surf, W // 2, DAY_EATER_CY, sad=self.game.hungry)
            self._draw_boosts(surf)
            roll_rect = pygame.Rect(*DAY_ROLL_RECT)
            draw_multi_btn_glow(surf, ["Roll Dice"], roll_rect, False, False, self.tick)
            play_rect = pygame.Rect(*DAY_PLAY_RECT)
            draw_multi_btn(surf, ["Just play with them,", "don't eat them."], play_rect, self.highlighted_play, True)
            return
        if phase == "play_anim":
            for cd in self.critter_data:
                self._draw_critter_card(surf, DAY_CARD_CENTERS[self.critter_data.index(cd)], DAY_CARD_CY, cd, draw_sprite=False)
            self._draw_eater_card(surf, W // 2, DAY_EATER_CY, sad=self.game.hungry)
            self._draw_boosts(surf)
            for cd in self.critter_data:
                if cd["caught"] == "caught":
                    continue
                idx = self.critter_data.index(cd)
                card_x = DAY_CARD_CENTERS[idx]
                card_y = DAY_CARD_CY
                sprite_size = int(75 * cd.get("size_var", 1.0))
                # Same sprite center as the normal card; only the dance bob changes.
                card_top = card_y - 100
                jump = math.sin(tick * 0.15) * 10
                self.game.critter_renderer.draw(
                    surf, cd["type"], card_x, card_top + 4 + sprite_size + jump,
                    sprite_size)
            draw_text(surf, "Playing...", (W // 2, 120), font=F28, color=(100, 255, 100))
            if tick > 120:
                self.game.total_days += 1
                if self.eaten == 0:
                    self.game.death("starved")
                if not self.game.death_reason:
                    self.game._regen_boosts()
                    self.game.phase = "night"
                    self.game.night.start()
                else:
                    self.game.phase = "gameover"
                return
            return
        if phase == "boost_anim":
            for cd in self.critter_data:
                if cd["caught"] is None:
                    self._draw_critter_card(surf, DAY_CARD_CENTERS[self.critter_data.index(cd)], DAY_CARD_CY, cd)
            self._draw_eater_card(surf, W // 2, DAY_EATER_CY, sad=self.game.hungry)
            self._draw_boosts(surf)
            self._draw_day_boost_die(surf, W // 2, 552, tick)
            if tick > 60:
                if self.pending_boost_mult > 0:
                    self.eater_speed = self.pending_boost_val
                    self.eater_speed_display = fmt_speed(self.pending_boost_val)
                    if self.chase_result:
                        self.chase_result["eater_final"] = self.eater_speed
                        self.chase_result["used_boost"] = True
                        self.chase_result["boost_val"] = self.pending_boost_mult
                        self.chase_phase = "chase_approach"
                    else:
                        self.chase_phase = "show_roll"
                else:
                    self.eater_speed_display = fmt_speed(self.eater_speed)
                    if self.chase_result:
                        self.chase_result["eater_final"] = self.eater_speed
                        self.chase_result["used_boost"] = False
                        self.chase_result["boost_val"] = 0
                        self.chase_phase = "chase_approach"
                    else:
                        self.chase_phase = "show_roll"
                self.chase_tick = 0
            return
        if not self.chase_result or "critter_data" not in self.chase_result:
            return
        cd = self.chase_result["critter_data"]
        name = cd["name"]
        caught = self.chase_result["eater_final"] >= cd["speed"]
        if phase == "chase_approach":
            card_idx = self.critter_data.index(cd)
            card_x = DAY_CARD_CENTERS[card_idx]
            card_y = DAY_CARD_CY
            card_w, card_h = DAY_CARD_W, DAY_CARD_H
            for i, other_cd in enumerate(self.critter_data):
                self._draw_critter_card(
                    surf, DAY_CARD_CENTERS[i], DAY_CARD_CY, other_cd,
                    draw_sprite=not (other_cd is cd and not caught and tick >= 26))
            self._draw_eater_card(surf, W // 2, DAY_EATER_CY, sad=self.game.hungry)
            self._draw_boosts(surf)
            t = min(1.0, tick / 40.0)
            fish_size = 112
            target_y = card_y - 88 + int(96 * cd.get("size_var", 1.0))
            # Mouth, not body center, must reach the critter's center.
            end_x = card_x + fish_size * 1.38
            eater_x = card_x + 360 + (end_x - (card_x + 360)) * t
            eater_y = target_y
            open_m = min(1.0, t * 3.0)
            self.game.critter_renderer.draw_fish(surf, eater_x, eater_y, 112, True, self.game.fin_damaged, open_mouth=open_m)
            # An escaping critter springs straight up before Eater arrives.
            if not caught and tick >= 26:
                sprite_size = int(75 * cd.get("size_var", 1.0))
                jump_t = min(1.0, (tick - 26) / 14.0)
                jump_height = 92 * math.sin(jump_t * math.pi / 2)
                self.game.critter_renderer.draw(
                    surf, cd["type"], card_x,
                    card_y - 88 + sprite_size - jump_height, sprite_size)
            if tick > 40:
                self.chase_phase = "chase_eat"
                self.chase_tick = 0
                if caught:
                    self.game.play_eating()
        elif phase == "chase_eat":
            card_idx = self.critter_data.index(cd)
            card_x = DAY_CARD_CENTERS[card_idx]
            card_y = DAY_CARD_CY
            card_w, card_h = DAY_CARD_W, DAY_CARD_H
            for i, other_cd in enumerate(self.critter_data):
                self._draw_critter_card(
                    surf, DAY_CARD_CENTERS[i], DAY_CARD_CY, other_cd,
                    draw_sprite=not (other_cd is cd and not caught))
            self._draw_eater_card(surf, W // 2, DAY_EATER_CY, sad=self.game.hungry)
            self._draw_boosts(surf)
            t = tick / 20.0
            eater_x = card_x + 112 * 1.38
            eater_y = card_y - 88 + int(96 * cd.get("size_var", 1.0))
            open_m = 1.0 + t * 0.5
            self.game.critter_renderer.draw_fish(surf, eater_x, eater_y, 112, True, self.game.fin_damaged, open_mouth=open_m)
            if not caught:
                sprite_size = int(75 * cd.get("size_var", 1.0))
                # Stay above Eater until the result is revealed.
                self.game.critter_renderer.draw(
                    surf, cd["type"], card_x,
                    card_y - 88 + sprite_size - 92 - min(1, tick / 20) * 12,
                    sprite_size)
            if caught:
                # Mark the target card; never render a second critter below it.
                draw_text(surf, "Eaten!", (card_x, card_y - 47), font=F32, color=(100, 255, 100))
            if tick > 20:
                if caught:
                    cd["caught"] = "caught"
                else:
                    cd["caught"] = "escaped"
                self.chase_phase = "result"
                self.chase_tick = 0
        elif phase == "chase_exit":
            card_idx = self.critter_data.index(cd)
            card_x = DAY_CARD_CENTERS[card_idx]
            card_y = DAY_CARD_CY
            card_w, card_h = DAY_CARD_W, DAY_CARD_H
            for i, other_cd in enumerate(self.critter_data):
                if other_cd is cd:
                    if caught:
                        self._draw_critter_card_eaten(surf, card_x, card_y, cd)
                    else:
                        self._draw_critter_card(surf, card_x, card_y, cd)
                else:
                    self._draw_critter_card(surf, DAY_CARD_CENTERS[i], DAY_CARD_CY, other_cd)
            self._draw_eater_card(surf, W // 2, DAY_EATER_CY, sad=self.game.hungry)
            self._draw_boosts(surf)
            t = tick / 30.0
            eater_x = card_x - card_w // 2 - 100 * t
            eater_y = card_y + 10
            self.game.critter_renderer.draw_fish(surf, eater_x, eater_y, 112, True, self.game.fin_damaged, open_mouth=1.0)
            if not caught and tick > 15:
                escape_t = max(0.0, (tick - 15) / 15.0)
                self.game.critter_renderer.draw(surf, cd["type"], card_x, card_y + 30 - 80 * escape_t, 120 * cd.get("size_var", 1.0))
                if escape_t >= 1.0 and tick > 25:
                    escape_back_t = (tick - 25) / 5.0
                    self.game.critter_renderer.draw(surf, cd["type"], card_x, card_y + 30 - 80 + 80 * escape_back_t, 120 * cd.get("size_var", 1.0))
            if tick > 30:
                self.chase_phase = "result"
                self.chase_tick = 0
        elif phase == "result":
            for i, other_cd in enumerate(self.critter_data):
                if other_cd is cd and caught:
                    self._draw_critter_card_eaten(surf, DAY_CARD_CENTERS[i], DAY_CARD_CY, cd)
                else:
                    self._draw_critter_card(surf, DAY_CARD_CENTERS[i], DAY_CARD_CY, other_cd)
            self._draw_eater_card(surf, W // 2, DAY_EATER_CY, sad=self.game.hungry)
            self._draw_boosts(surf)
            if not self._result_processed:
                if caught:
                    self.eaten += 1
                    self.game.hungry = False
                    self.chase_result["caught"] = caught
                    per_critter = 0.125 if self.eaten == 3 else 0.0625
                    self.game.size = round(self.game.size + per_critter, 3)
                    if self.game.size > self.game.max_size:
                        self.game.max_size = self.game.size
                    self.game.check_level_up()
                self._result_processed = True
            remaining = [c for c in self.critter_data if c["caught"] is None]
            if not remaining:
                draw_text(surf, "All Critters Gone!", (W // 2, 60), font=F36, color=(100, 255, 100))
                g = growth_amount(self.eaten)
                draw_text(surf, f"Growth: +{g:.3f} inch", (W // 2, 110), font=F22, color=(100, 255, 100))
            else:
                # The chase result advances automatically after one second.
                pass

    def handle_event(self, event):
        if self.cooldown > 0:
            return False
        if self.chase_phase == "result":
            # Keep the result on screen for one second, then advance automatically.
            # Do not let clicks skip it or activate controls underneath.
            return event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN)
        if self.phase == "choice":
            if event.type == pygame.MOUSEMOTION:
                mx, my = event.pos
                self.highlighted_card = -1
                self.highlighted_boost = -1
                self.highlighted_roll = False
                self.highlighted_play = False
                if self.can_roll:
                    roll_rect = pygame.Rect(*DAY_ROLL_RECT)
                    if roll_rect.collidepoint(mx, my):
                        self.highlighted_roll = True
                    else:
                        play_rect = pygame.Rect(*DAY_PLAY_RECT)
                        if play_rect.collidepoint(mx, my):
                            self.highlighted_play = True
                    # Also check boost hover regardless of can_roll
                    for i in range(len(self.boost_used)):
                        cy = H - 68 - i * 78
                        boost_cx = 26 + 56
                        if abs(mx - boost_cx) < 56 and abs(my - cy) < 35:
                            if not self.can_roll and self.chase_phase == "show_roll" and not self.boost_used[i]:
                                self.highlighted_boost = i
                                break
                else:
                    card_y = DAY_CARD_CY
                    card_h = 150
                    for i in range(len(self.critter_data)):
                        card_x = DAY_CARD_CENTERS[i]
                        cx = card_x
                        cy = card_y
                        if abs(mx - cx) < DAY_CARD_W // 2 and (DAY_CARD_CY - 100) <= my <= (DAY_CARD_CY - 100 + DAY_CARD_H) and self.critter_data[i]["caught"] is None:
                            self.highlighted_card = i
                            break
                    if self.highlighted_card == -1 and self.chase_phase != "result":
                        for i in range(len(self.boost_used)):
                            cy = H - 68 - i * 78
                            boost_cx = 26 + 56
                            if abs(mx - boost_cx) < 56 and abs(my - cy) < 35:
                                if self.chase_phase == "show_roll" and not self.boost_used[i]:
                                    self.highlighted_boost = i
                                break
                    if self.highlighted_card == -1 and self.highlighted_boost == -1:
                        play_rect = pygame.Rect(*DAY_PLAY_RECT)
                        if play_rect.collidepoint(mx, my):
                            self.highlighted_play = True
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mx, my = event.pos
                # Check boost clicks - can click before or after selecting a critter
                if self.highlighted_boost >= 0 and not self.can_roll and self.chase_phase == "show_roll":
                    idx = self.highlighted_boost
                    if not self.boost_used[idx]:
                        boost_val = self.boost_values[idx]
                        self.highlighted_boost = -1
                        self.game.begin_boost_calculator("day", idx, boost_val)
                        return True
                if not self.can_roll and self.chase_phase in ("show_roll", "result"):
                    if self.chase_phase == "show_roll":
                        self.highlighted_card = -1
                    play_rect = pygame.Rect(*DAY_PLAY_RECT)
                    if play_rect.collidepoint(mx, my):
                        self.game.hungry = False
                        self.chase_phase = "play_anim"
                        self.chase_tick = 0
                        return True
                    if self._check_critter_click(mx, my):
                        cd = self.critter_data[self.highlighted_card]
                        if cd["caught"] is None:
                            used_boost = self.pending_boost_mult > 0
                            self.chase_result = {
                                "critter_data": cd,
                                "eater_final": self.eater_speed,
                                "used_boost": used_boost,
                                "boost_val": self.pending_boost_mult if used_boost else 0,
                            }
                            self._result_processed = False
                            self.chase_phase = "chase_approach"
                            self.chase_tick = 0
                            return True
                    return False
                if not self.can_roll:
                    return False
                roll_rect = pygame.Rect(*DAY_ROLL_RECT)
                if roll_rect.collidepoint(mx, my):
                    self.can_roll = False
                    self.roll_anim_tick = 0
                    self.chase_phase = "roll_anim"
                    self.chase_tick = 0
                    self.game.play_dice()
                    return True
                play_rect = pygame.Rect(*DAY_PLAY_RECT)
                if play_rect.collidepoint(mx, my):
                    self.game.hungry = False
                    self.chase_phase = "play_anim"
                    self.chase_tick = 0
                    return True
                return False

        elif self.phase == "result":
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                return True

        return False

    def _check_critter_click(self, mx, my):
        """Check if click is over a critter card and set highlighted_card."""
        card_y = DAY_CARD_CY
        card_h = 150
        for i in range(len(self.critter_data)):
            card_x = DAY_CARD_CENTERS[i]
            if abs(mx - card_x) < DAY_CARD_W // 2 and (DAY_CARD_CY - 100) <= my <= (DAY_CARD_CY - 100 + DAY_CARD_H) and self.critter_data[i]["caught"] is None:
                self.highlighted_card = i
                return True
        return False

    def update(self):
        self.tick += 1
        if self.cooldown > 0:
            self.cooldown -= 1
        if self.chase_phase:
            self.chase_tick += 1
            if self.chase_phase == "result" and self.chase_tick >= FPS:
                # Processing the catch occurs during the first result draw.
                remaining = [c for c in self.critter_data if c["caught"] is None]
                if not remaining:
                    self.game.total_days += 1
                    if self.eaten == 0:
                        self.game.death("starved")
                    if not self.game.death_reason:
                        self.chase_phase = ""
                        self.chase_result = None
                        self.game.phase = "night"
                        self.game.night.start()
                    else:
                        self.game.phase = "gameover"
                else:
                    self.chase_phase = "show_roll"
                    self.chase_tick = 0
                    self.can_roll = False
                    self._result_processed = False
                    self.chase_result = None

    def draw(self, surf):
        bg = self.game.background
        if self.chase_phase:
            self._draw_chase_anim(surf)
            if self.chase_phase in ("chase_approach", "chase_eat", "chase_exit", "result"):
                # Preserve the normal HUD and controls while the eating animation runs.
                draw_text(surf, get_zone_name(self.game.habitat_size), (W // 2, 14), font=F16, color=(255, 255, 200))
                self.game.progress_bar.draw(surf, self.game.size, W - 220, 10, 200)
                draw_text(surf, "Eater meets three tiny critters that would like to be friends.", (W // 2, 51), font=F18, color=(255, 220, 200))
                draw_text(surf, "Click on them to eat them.", (W // 2, 89), font=F20, color=(255, 220, 200))
                draw_multi_btn_glow(surf, ["Roll Dice"], pygame.Rect(*DAY_ROLL_RECT), False, False, self.tick)
                draw_multi_btn(surf, ["Just play with them,", "don't eat them."], pygame.Rect(*DAY_PLAY_RECT), False, False)
            # Topmost escape result overlay, after every fish, card, and HUD.
            if self.chase_result and "critter_data" in self.chase_result:
                escaped_cd = self.chase_result["critter_data"]
                escaped = self.chase_result["eater_final"] < escaped_cd["speed"]
                if escaped and self.chase_phase == "result":
                    idx = self.critter_data.index(escaped_cd)
                    draw_text(surf, "ESCAPED!", (DAY_CARD_CENTERS[idx], 175),
                              font=F32, color=(255, 100, 100))
        elif self.phase == "choice":
            bg.draw_open_ocean(surf) if self.game.habitat_size < 1 else \
            bg.draw_mangrove(surf) if self.game.habitat_size < 2 else \
            bg.draw_kelp_forest(surf) if self.game.habitat_size < 3 else \
            bg.draw_coral_reef(surf)
            draw_text(surf, get_zone_name(self.game.habitat_size), (W // 2, 14), font=F16, color=(255, 255, 200))
            self.game.progress_bar.draw(surf, self.game.size, W - 220, 10, 200)
            draw_text(surf, "Eater meets three tiny critters that would like to be friends.", (W // 2, 51), font=F18, color=(255, 220, 200))
            draw_text(surf, "Click on them to eat them.", (W // 2, 89), font=F20, color=(255, 220, 200))
            for cd in self.critter_data:
                self._draw_critter_card(surf, DAY_CARD_CENTERS[self.critter_data.index(cd)], DAY_CARD_CY, cd)
            sad = self.game.hungry
            self._draw_eater_card(surf, W // 2, DAY_EATER_CY, sad=sad)
            if self.game.hungry:
                draw_text(surf, "Eater is Hungry!", (W // 2, 430), font=F22, color=(255, 150, 100))
            self._draw_boosts(surf)
            roll_rect = pygame.Rect(*DAY_ROLL_RECT)
            draw_multi_btn_glow(surf, ["Roll Dice"], roll_rect, self.highlighted_roll, self.can_roll, self.tick)
            # Play with them button (right bottom) - taller for 2 lines, larger bold font
            play_rect = pygame.Rect(*DAY_PLAY_RECT)
            draw_multi_btn(surf, ["Just play with them,", "don't eat them."], play_rect, self.highlighted_play, not self.chase_phase or self.chase_phase == "show_roll")

        elif self.phase == "result":
            bg.draw_night(surf) if self.game.next_phase == "night" else \
            bg.draw_open_ocean(surf) if self.game.habitat_size < 1 else \
            bg.draw_mangrove(surf) if self.game.habitat_size < 2 else \
            bg.draw_kelp_forest(surf) if self.game.habitat_size < 3 else \
            bg.draw_coral_reef(surf)
            self.game.progress_bar.draw(surf, self.game.size, W - 220, 18, 200)
            if self.game.death_reason:
                draw_text(surf, "GAME OVER", (W // 2, 40), font=F40, color=(255, 100, 100))
                draw_text(surf, f"Caused by: {self.game.death_reason.upper()}", (W // 2, 90), font=F24, color=(255, 200, 200))
                draw_text(surf, "[Click to try again]", (W // 2, H - 40), font=F20)
            elif self.eaten == 3:
                draw_text(surf, "All three animals caught!", (W // 2, 40), font=F32, color=(100, 255, 100))
                draw_text(surf, "Digesting...", (W // 2, 80), font=F24, color=(200, 255, 200))
                g = growth_amount(3)
                draw_text(surf, f"Growth: +{g:.3f} inch", (W // 2, 120), font=F22, color=(100, 255, 100))
                draw_text(surf, f"New size: {fmt_size_short(self.game.size)}", (W // 2, 155), font=F20, color=(200, 255, 200))
                for i, cd in enumerate(self.critter_data):
                    status = "CAUGHT!" if cd["caught"] == "caught" else "ESCAPED"
                    status_c = (100, 255, 100) if cd["caught"] == "caught" else (255, 100, 100)
                    draw_text(surf, f"{cd['name']}: {status}", (W // 2, 240 + i * 30), font=F16, color=status_c)
                draw_text(surf, "[Click to continue]", (W // 2, H - 40), font=F20)
            elif self.eaten > 0:
                draw_text(surf, f"You ate {self.eaten}/3 critters", (W // 2, 40), font=F28, color=(100, 255, 100))
                g = growth_amount(self.eaten)
                draw_text(surf, f"Growth: +{g:.3f} inch", (W // 2, 105), font=F22, color=(100, 255, 100))
                draw_text(surf, f"New size: {fmt_size_short(self.game.size)}", (W // 2, 115), font=F20, color=(200, 255, 200))
                for i, cd in enumerate(self.critter_data):
                    status = "CAUGHT!" if cd["caught"] == "caught" else "ESCAPED"
                    status_c = (100, 255, 100) if cd["caught"] == "caught" else (255, 100, 100)
                    draw_text(surf, f"{cd['name']}: {status}", (W // 2, 200 + i * 30), font=F16, color=status_c)
                draw_text(surf, "[Click to continue]", (W // 2, H - 40), font=F20)
            else:
                if self.game.hungry:
                    draw_text(surf, "Eater is Hungry!", (W // 2, 40), font=F32, color=(255, 150, 100))
                    draw_text(surf, "One more hungry day and you'll starve!", (W // 2, 80), font=F18, color=(255, 100, 100))
                    sad = True
                else:
                    draw_text(surf, "Eater is Hungry!", (W // 2, 40), font=F32, color=(255, 150, 100))
                    draw_text(surf, "You didn't eat anything today.", (W // 2, 80), font=F20, color=(255, 200, 150))
                    sad = True
                self._draw_eater_card(surf, W // 2, 200, sad=sad)
                draw_text(surf, "[Click to continue]", (W // 2, H - 40), font=F20)




class NightState:
    """Night phase: Tuna chases Eater. Eater can use speed boosts to escape."""

    def __init__(self, game):
        self.game = game
        self.tuna_speed = 0
        self.eater_speed = 0
        self.result = None
        self.phase = "choice"
        self.highlighted_action = -1
        self.highlighted_boost = -1
        self.tick = 0
        self.chase_tick = 0
        self.roll_anim_tick = 0
        self.boost_values = []
        self.boost_used = []
        self.boosts_available = []
        self.pending_boost_mult = 0
        self.pending_boost_val = 0
        self.chase_result = None
        self._result_processed = False

    def start(self):
        self.boost_values = list(self.game.boosts_escape)
        self.boost_used = list(self.game._shared_boost_used[:len(self.game.boosts_escape)])
        self.boosts_available = [b for i, b in enumerate(self.game.boosts_escape)
                                 if not self.boost_used[i]]
        self.tuna_speed = 0
        self.eater_speed = 0
        self.result = None
        self.phase = "choice"
        self.highlighted_action = -1
        self.highlighted_boost = -1
        self.tick = 0
        self.chase_tick = 0
        self.roll_anim_tick = 0
        self.pending_boost_mult = 0
        self.pending_boost_val = 0
        self.chase_result = None
        self._result_processed = False
        self._death_tick = 0

    def _roll_night(self):
        if self.game.size < 1:
            tuna_sides = 12
        elif self.game.size < 2:
            tuna_sides = 15
        elif self.game.size < 3:
            tuna_sides = 18
        else:
            tuna_sides = 20
        self.tuna_speed = Fraction(random.randint(1, tuna_sides) + random.randint(1, tuna_sides))
        self.eater_speed = Fraction(random.randint(1, 8) + random.randint(1, 8))
        if self.pending_boost_mult > 0:
            self.eater_speed *= self.pending_boost_mult
        self.chase_result["eater_final"] = self.eater_speed
        self.chase_result["tuna_final"] = self.tuna_speed

    def _apply_boost(self, boost_val):
        self.pending_boost_mult = boost_val
        self.pending_boost_val = self.eater_speed * boost_val if self.eater_speed > 0 else boost_val
        self.chase_phase = "boost_anim"
        self.chase_result = {"used_boost": True, "boost_val": boost_val}
        self.chase_tick = 0
        self._result_processed = False
        self.game.play_dice()

    def _draw_tuna(self, surf, cx, cy):
        t = self.tick * 0.04
        bob = cy + 5 * math.sin(t)
        size = 120
        pygame.draw.ellipse(surf, (80, 80, 140),
                            (cx - size * 1.5, bob - size * 0.4, size * 3, size * 0.8))
        tw = math.sin(t * 2) * 3
        tp = [(cx + size * 1.3, bob),
              (cx + size * 2.2, bob - size * 0.6 + tw),
              (cx + size * 2.2, bob + size * 0.6 + tw)]
        pygame.draw.polygon(surf, (70, 70, 120), tp)
        pygame.draw.polygon(surf, (60, 60, 110), [
            (cx - size * 0.5, bob - size * 0.4),
            (cx, bob - size * 0.9),
            (cx + size * 0.5, bob - size * 0.4)])
        pygame.draw.circle(surf, (255, 255, 200),
                           (int(cx - size * 0.8), int(bob - size * 0.1)), int(size * 0.15))
        pygame.draw.circle(surf, (200, 200, 50),
                           (int(cx - size * 0.8 + 1), int(bob - size * 0.1)), int(size * 0.08))
        for i in range(4):
            tx = cx - size * 1.2 + i * size * 0.25
            pygame.draw.polygon(surf, (255, 255, 255), [
                (tx, bob + size * 0.2),
                (tx + 2, bob + size * 0.2),
                (tx + 1, bob + size * 0.5)])

    def _draw_tuna_window(self, surf, cx, cy):
        card_w, card_h = 300, 300
        x, y = cx - card_w // 2, cy - card_h // 2
        border = (100, 100, 180)
        pygame.draw.rect(surf, (25, 25, 45), (x, y, card_w, card_h), border_radius=8)
        pygame.draw.rect(surf, border, (x, y, card_w, card_h), 2, border_radius=8)
        self._draw_tuna(surf, cx, cy - 10)
        die_x, die_y = cx, cy + card_h // 2 - 15
        if self.phase in ("choice", "roll_anim", "boost_anim"):
            draw_die(surf, die_x, die_y, "?", 12, (255, 80, 60), self.phase == "roll_anim")
        else:
            draw_die(surf, die_x, die_y, fmt_speed(self.tuna_speed), 12, (255, 100, 100))
        draw_text(surf, "Baby Tuna:", (x + 21, y + 24), (255, 100, 100), F14)

    def _draw_eater_window(self, surf, cx, cy):
        card_w, card_h = 300, 300
        x, y = cx - card_w // 2, cy - card_h // 2
        border = (255, 180, 40)
        pygame.draw.rect(surf, (45, 35, 25), (x, y, card_w, card_h), border_radius=8)
        pygame.draw.rect(surf, border, (x, y, card_w, card_h), 2, border_radius=8)
        sad = self.phase == "chase_result" and self.result == "died"
        fs = (NIGHT_EATER_SIZE * 2)
        self.game.critter_renderer.draw_fish(surf, cx, cy - 10, fs, flip_h=False, fin_damaged=self.game.fin_damaged, sad_face=sad)
        die_x, die_y = cx, cy + card_h // 2 - 15
        if self.phase in ("choice", "roll_anim", "boost_anim"):
            draw_die(surf, die_x, die_y, "?", 10, (255, 80, 60), self.phase == "roll_anim")
        else:
            die_color = (255, 180, 60) if self.eater_speed > 5 else (255, 120, 60)
            draw_die(surf, die_x, die_y, fmt_speed(self.eater_speed), 10, die_color)
        draw_text(surf, "EATER", (x + 21, y + 24), (255, 200, 100), F20)

    def _draw_eater_window_frame(self, surf, cx, cy):
        card_w, card_h = 300, 300
        x, y = cx - card_w // 2, cy - card_h // 2
        border = (255, 180, 40)
        pygame.draw.rect(surf, (45, 35, 25), (x, y, card_w, card_h), border_radius=8)
        pygame.draw.rect(surf, border, (x, y, card_w, card_h), 2, border_radius=8)
        die_x, die_y = cx, cy + card_h // 2 - 15
        die_color = (255, 180, 60) if self.eater_speed > 5 else (255, 120, 60)
        draw_die(surf, die_x, die_y, fmt_speed(self.eater_speed), 10, die_color)
        draw_text(surf, "EATER", (x + 21, y + 24), (255, 200, 100), F20)

    def _draw_night_boost_die(self, surf, die_x, die_y):
        """Boost animation using precisely the normal Eater die palette."""
        base_speed = self.eater_speed
        multiplier = self.pending_boost_mult or 1
        resulting_speed = base_speed * multiplier
        final_color = (255, 180, 60) if resulting_speed > 5 else (255, 120, 60)
        tick = self.chase_tick
        if tick < 40:
            scale = 1.0 + math.sin(math.pi * tick / 40) * 0.65
            # Let the original polygon/font drawing determine the shape.
            temp = pygame.Surface((110, 110), pygame.SRCALPHA)
            draw_die(temp, 55, 55, fmt_speed(base_speed), 10, final_color)
            tw = max(1, int(110 * scale))
            grown = pygame.transform.smoothscale(temp, (tw, tw))
            surf.blit(grown, grown.get_rect(center=(die_x, die_y)))
        else:
            draw_die(surf, die_x, die_y, fmt_speed(resulting_speed), 10, final_color)
            if multiplier != 1:
                draw_text(surf, f"x{fmt_speed(multiplier)}", (die_x, die_y + 53),
                          font=F20, color=(255, 220, 120))

    def _draw_boosts(self, surf):
        x = 24
        for i, b in enumerate(self.boost_values):
            cy = H - 68 - i * 78
            card_w, card_h = 110, 70
            cx = x + card_w // 2
            is_used = self.boost_used[i]
            is_highlighted = self.highlighted_boost == i
            if is_used:
                pygame.draw.rect(surf, (30, 50, 35), (x, cy - card_h // 2, card_w, card_h), border_radius=6)
                draw_text(surf, "x" + str(b), (cx, cy), (100, 100, 100), F18)
            else:
                border = (100, 255, 100) if is_highlighted else (80, 180, 80)
                pygame.draw.rect(surf, (30, 50, 35), (x, cy - card_h // 2, card_w, card_h), border_radius=6)
                pygame.draw.rect(surf, border, (x, cy - card_h // 2, card_w, card_h), 2, border_radius=6)
                draw_text(surf, "x" + str(b), (cx, cy), (100, 255, 150), F18)
        if self.boosts_available and self.phase in ("choice", "roll_result"):
            boost_cx = x + 110 // 2
            top_cy = H - 68 - (len(self.boost_values) - 1) * 78
            draw_text(surf, "Use Speed", (boost_cx, top_cy - 45 - 40), (200, 255, 200), F24)
            draw_text(surf, "Boost!", (boost_cx, top_cy - 45 - 16), (200, 255, 200), F24)

    def _draw_chase_anim(self, surf):
        tick = self.chase_tick
        phase = self.phase
        if not self.chase_result:
            return
        eaten = self.chase_result["tuna_final"] > self.chase_result["eater_final"]
        eater_x, eater_y = W // 2 - 205, H // 2 - 26

        if phase == "chase_approach":
            self._draw_eater_window(surf, eater_x, eater_y)
            self._draw_tuna_window(surf, W // 2 + 205, eater_y)
            return

        if phase == "chase_swim":
            swim_progress = min(1.0, tick / 80.0)
            tuna_x = W + 60 - (W + 60 - eater_x) * swim_progress
            if tick > 50 and not eaten:
                esc_t = (tick - 50) / 30.0
                self._draw_eater_window_frame(surf, eater_x, eater_y)
                fs = (NIGHT_EATER_SIZE * 2)
                fish_y = eater_y - 10 - 60 * esc_t
                self.game.critter_renderer.draw_fish(surf, eater_x, fish_y, fs, flip_h=False, fin_damaged=self.game.fin_damaged)
            else:
                self._draw_eater_window(surf, eater_x, eater_y)
            self._draw_tuna(surf, tuna_x, eater_y)
            if tick > 80:
                self.phase = "chase_eat"
                self.chase_tick = 0
            return

        if phase == "chase_eat":
            # Hold the tuna over Eater for 30 additional frames (0.5 s at 60 FPS).
            t = min(1.0, tick / 20.0)
            fs = (NIGHT_EATER_SIZE * 2)
            if eaten:
                if not self.game.fin_damaged:
                    if tick >= 40:
                        self.game.fin_damaged = True
                        self.phase = "chase_result"
                        self.chase_tick = 0
                        self.result = "fin_lost"
                        self._result_processed = True
                    else:
                        open_m = 1.0 + t * 0.5
                        self.game.critter_renderer.draw_fish(surf, eater_x, eater_y, fs, flip_h=True, fin_damaged=False, open_mouth=open_m)
                        self._draw_tuna(surf, eater_x + 50, eater_y)
                else:
                    if tick >= 40:
                        self.game.death("eaten_by_tuna")
                        self.phase = "chase_result"
                        self.chase_tick = 0
                        self.result = "died"
                        self._result_processed = True
                    else:
                        open_m = 1.0 + t * 0.5
                        self.game.critter_renderer.draw_fish(surf, eater_x, eater_y, fs, flip_h=True, fin_damaged=True, open_mouth=open_m)
                        self._draw_tuna(surf, eater_x + 50, eater_y)
            else:
                escape_t = max(0.0, (tick + 30) / 40.0)
                tuna_draw_x = eater_x + 100 - 300 * escape_t
                self._draw_tuna(surf, tuna_draw_x, eater_y)
                self._draw_eater_window_frame(surf, eater_x, eater_y)
                fish_y = eater_y - 10 - 60 - 60 * min(1.0, escape_t)
                self.game.critter_renderer.draw_fish(surf, eater_x, fish_y, fs, flip_h=False, fin_damaged=self.game.fin_damaged)
                if tick > 20:
                    self.phase = "chase_result"
                    self.chase_tick = 0
            return

        if phase == "chase_result":
            if not self._result_processed:
                if eaten:
                    self.result = "died"
                    self._death_tick = self.chase_tick
                else:
                    self.result = "escaped"
                self._result_processed = True
            if self.result == "fin_lost":
                self._draw_eater_window(surf, eater_x, eater_y)
                self._draw_tuna_window(surf, W // 2 + 205, eater_y)
                draw_text(surf, "Eater was able to escape", (W // 2, H - 96), font=F28, color=(255, 220, 100))
                draw_text(surf, "but lost his fin!", (W // 2, H - 60), font=F28, color=(255, 150, 100))
                draw_text(surf, "[Click to continue]", (W // 2, H - 23), font=F20, color=(255, 255, 200))
            elif self.result == "died":
                draw_text(surf, "GAME OVER!", (W // 2, H // 2 + 80), font=F40, color=(255, 100, 100))
                draw_text(surf, "Eaten by Baby Tuna!", (W // 2, H // 2 + 120), font=F28, color=(255, 150, 150))
                draw_text(surf, "[Click to see results]", (W // 2, H - 40), font=F20, color=(255, 255, 200))
            else:
                self._draw_eater_window(surf, eater_x, eater_y)
                self._draw_tuna_window(surf, W // 2 + 205, eater_y)
                draw_text(surf, "ESCAPED!", (W // 2, H - 145), font=F40, color=(100, 255, 100))
                draw_text(surf, "You escaped the night safely.", (W // 2, H - 105), font=F22, color=(150, 255, 200))
                draw_text(surf, "[Click to continue]", (W // 2, H - 40), font=F20, color=(200, 255, 200))

    def handle_event(self, event):
        if self.phase == "boost_anim":
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                return True
            if self.chase_tick > 60:
                if self.chase_result:
                    self.eater_speed = self.pending_boost_val
                    self.phase = "roll_result"
                self.chase_tick = 0
            return False
        if self.phase == "roll_result":
            if event.type == pygame.MOUSEMOTION:
                mx, my = event.pos
                self.highlighted_action = -1
                self.highlighted_boost = -1
                swim_rect = pygame.Rect(W // 2 + 60, H - 104, 410, 96)
                if swim_rect.collidepoint(mx, my):
                    self.highlighted_action = 1
                for i, b in enumerate(self.boost_values):
                    cy = H - 68 - i * 78 - 35
                    boost_rect = pygame.Rect(24, cy, 110, 70)
                    if boost_rect.collidepoint(mx, my) and not self.boost_used[i]:
                        self.highlighted_boost = i
                        break
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    mx, my = event.pos
                    swim_rect = pygame.Rect(W // 2 + 60, H - 104, 410, 96)
                    if swim_rect.collidepoint(mx, my):
                        self.chase_result = {"tuna_final": self.tuna_speed, "eater_final": self.eater_speed}
                        self.phase = "chase_swim"
                        self.chase_tick = 0
                        self.game.play_dice()
                        return True
                    for i, b in enumerate(self.boost_values):
                        cy = H - 68 - i * 78 - 35
                        boost_rect = pygame.Rect(24, cy, 110, 70)
                        if boost_rect.collidepoint(mx, my) and not self.boost_used[i]:
                            self.highlighted_boost = -1
                            self.game.begin_boost_calculator("night", i, b)
                            return True
                    return False
            return False
        if self.phase == "chase_result":
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                if self.result == "died":
                    if self.chase_tick - self._death_tick >= 60:
                        self.game.death("tuna")
                        self.game.phase = "gameover"
                    return True
                else:
                    self.game.finish_night()
                return True
            return False
        if self.phase == "choice":
            if event.type == pygame.MOUSEMOTION:
                mx, my = event.pos
                self.highlighted_action = -1
                self.highlighted_boost = -1
                roll_rect = pygame.Rect(W // 2 - 190, H - 104, 380, 96)
                if roll_rect.collidepoint(mx, my):
                    self.highlighted_action = 0
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    mx, my = event.pos
                    roll_rect = pygame.Rect(W // 2 - 190, H - 104, 380, 96)
                    if roll_rect.collidepoint(mx, my):
                        self.chase_result = {"used_boost": False, "boost_val": 0}
                        self.phase = "roll_anim"
                        self.roll_anim_tick = 0
                        self.game.play_dice()
                        return True
                    return False
        return False

    def update(self):
        self.tick += 1
        if self.phase == "roll_anim":
            self.roll_anim_tick += 1
            if self.roll_anim_tick > 30:
                self._roll_night()
                self.chase_result["eater_speed"] = self.eater_speed
                self.phase = "roll_result"
                self.game.play_dice()
        elif self.phase in ("chase_approach", "chase_swim", "chase_eat", "chase_result", "boost_anim"):
            self.chase_tick += 1
            if self.phase == "boost_anim" and self.chase_tick > 60:
                if self.chase_result:
                    self.eater_speed = self.pending_boost_val
                    self.phase = "roll_result"
                self.chase_tick = 0

    def draw(self, surf):
        bg = self.game.background
        bg.draw_night(surf)
        cx = W // 2
        draw_text(surf, get_zone_name(self.game.habitat_size), (cx, 17), font=F16, color=(255, 255, 200))
        self.game.progress_bar.draw(surf, self.game.size, W - 220, 14, 200)

        if self.phase == "choice":
            draw_text(surf, "NIGHT PHASE", (cx, 75), font=F32, color=(255, 200, 200))
            draw_text(surf, "A baby tuna approaches in the darkness!", (cx, 131), font=F18, color=(200, 200, 200))
            eater_x, eater_y = W // 2 - 205, H // 2 - 26
            tuna_x, tuna_y = W // 2 + 205, H // 2 - 26
            self._draw_eater_window(surf, eater_x, eater_y)
            self._draw_tuna_window(surf, tuna_x, tuna_y)
            self._draw_boosts(surf)
            roll_rect = pygame.Rect(W // 2 - 190, H - 104, 380, 96)
            draw_multi_btn_glow(surf, ["Roll Dice"], roll_rect, self.highlighted_action == 0, True, self.tick)
            if self.game.fin_damaged:
                draw_text(surf, "WARNING: Fin damaged!", (cx, H - 140), (255, 100, 100), font=F18)

        elif self.phase == "roll_anim":
            draw_text(surf, get_zone_name(self.game.habitat_size), (cx, 17), font=F16, color=(255, 255, 200))
            self.game.progress_bar.draw(surf, self.game.size, W - 220, 14, 200)
            draw_text(surf, "NIGHT PHASE", (cx, 75), font=F32, color=(255, 200, 200))
            draw_text(surf, "A baby tuna approaches in the darkness!", (cx, 131), font=F18, color=(200, 200, 200))
            self._draw_eater_window(surf, W // 2 - 205, H // 2 - 26)
            self._draw_tuna_window(surf, W // 2 + 205, H // 2 - 26)
            draw_text(surf, "Rolling...", (W // 2, H // 2 + 80), font=F28, color=(255, 255, 150))

        elif self.phase == "boost_anim":
            draw_text(surf, get_zone_name(self.game.habitat_size), (cx, 17), font=F16, color=(255, 255, 200))
            self.game.progress_bar.draw(surf, self.game.size, W - 220, 14, 200)
            draw_text(surf, "NIGHT PHASE", (cx, 75), font=F32, color=(255, 200, 200))
            draw_text(surf, "A baby tuna approaches in the darkness!", (cx, 131), font=F18, color=(200, 200, 200))
            self._draw_eater_window(surf, W // 2 - 205, H // 2 - 26)
            self._draw_tuna_window(surf, W // 2 + 205, H // 2 - 26)
            eater_die_x = W // 2 - 205
            eater_die_y = H // 2 - 26 + 85
            self._draw_night_boost_die(surf, eater_die_x, eater_die_y)

        elif self.phase == "roll_result":
            draw_text(surf, "NIGHT PHASE", (cx, 75), font=F32, color=(255, 200, 200))
            draw_text(surf, "A baby tuna approaches in the darkness!", (cx, 131), font=F18, color=(200, 200, 200))
            self._draw_eater_window(surf, W // 2 - 205, H // 2 - 26)
            self._draw_tuna_window(surf, W // 2 + 205, H // 2 - 26)
            draw_text(surf, f"Baby Tuna: {fmt_speed(self.tuna_speed)}", (W // 2 + 205, H // 2 + 155), font=F22, color=(255, 100, 100))
            draw_text(surf, f"Eater: {fmt_speed(self.eater_speed)}", (W // 2 - 205, H // 2 + 155), font=F22, color=(255, 200, 100))
            self._draw_boosts(surf)
            swim_rect = pygame.Rect(W // 2 + 60, H - 104, 410, 96)
            draw_multi_btn_glow(surf, ["Swim For Your", "Life!"], swim_rect, self.highlighted_action == 1, True, self.tick)

        elif self.phase in ("chase_approach", "chase_swim", "chase_eat", "chase_result"):
            self._draw_chase_anim(surf)



class GameOverState:
    def __init__(self):
        self.tick = 0

    def update(self):
        self.tick += 1

    def draw(self, surf, game):
        surf.fill(BG_OVER)
        cx, cy = W//2, H//2
        draw_text(surf, "GAME OVER", (cx, cy - 80), font=F52, color=(255, 100, 100))
        draw_text(surf, f"Caused by: {game.death_reason.upper()}", (cx, cy - 20), font=F28, color=(255, 200, 200))
        draw_text(surf, f"Size reached: {fmt_size_short(game.max_size)}", (cx, cy + 30), font=F22, color=(255, 220, 220))
        draw_text(surf, f"Days survived: {game.total_days}", (cx, cy + 70), font=F22, color=(255, 220, 220))
        draw_text(surf, "[Click to try again]", (cx, H - 60), font=F20, color=(255, 255, 200))


class WinState:
    def __init__(self):
        self.tick = 0
        self.particles = []

    def handle_event(self, event):
        if self.tick >= 120 and event.type == pygame.MOUSEBUTTONDOWN:
            return True
        return False

    def update(self):
        self.tick += 1
        if self.tick % 5 == 0:
            self.particles.append({
                "x": random.randint(0, W),
                "y": H + 10,
                "vy": -random.uniform(2, 5),
                "vx": random.uniform(-1, 1),
                "color": random.choice([(255, 255, 100), (255, 150, 200), (150, 255, 200), (200, 200, 255)]),
                "size": random.randint(2, 5),
            })
        self.particles = [p for p in self.particles if p["y"] > -20]
        for p in self.particles:
            p["y"] += p["vy"]
            p["x"] += p["vx"]

    def draw(self, surf, game):
        for y in range(0, H, 2):
            ratio = y / H
            r = int(10 + ratio * 20)
            g = int(40 + ratio * 40)
            b = int(30 + ratio * 30)
            pygame.draw.line(surf, (r, g, b), (0, y), (W, y))

        for p in self.particles:
            pygame.draw.circle(surf, p["color"], (int(p["x"]), int(p["y"])), p["size"])

        cx = W // 2
        draw_text(surf, "Congratulations, Eater survived", (cx, 35), font=F28, color=(255, 255, 150))
        draw_text(surf, "and grew to 4 inches!", (cx, 70), font=F28, color=(255, 255, 150))
        draw_text(surf, "Now Eater can lay eggs!", (cx, 105), font=F24, color=(200, 255, 200))

        game.critter_renderer.draw_fish(surf, cx, 240, 80, flip_h=False)

        for row in range(10):
            for col in range(10):
                ex = cx - 135 + col * 30
                ey = 340 + row * 20 + int(2 * math.sin(self.tick * 0.05 + (row + col) * 0.35))
                pygame.draw.ellipse(surf, (255, 245, 220), (ex - 6, ey - 8, 12, 16))
                pygame.draw.ellipse(surf, (220, 200, 170), (ex - 6, ey - 8, 12, 16), 1)
                pygame.draw.circle(surf, (255, 255, 255), (ex - 2, ey - 4), 2)

        if self.tick >= 120:
            draw_text(surf, "[Click to continue]", (cx, H - 30), font=F20, color=(255, 255, 200))


class SizeProgressBar:
    """Draws a size progress bar from 0.25\" to 4\"."""
    def draw(self, surf, size, x, y, width, height=14):
        min_sz, max_sz = 0.25, 4.0
        frac = max(0, min(1, (size - min_sz) / (max_sz - min_sz)))
        pygame.draw.rect(surf, (40, 40, 60), (x, y, width, height), border_radius=4)
        if frac > 0:
            fill_w = int(width * frac)
            grad = pygame.Surface((fill_w, height), pygame.SRCALPHA)
            for i in range(fill_w):
                ratio = i / max(1, fill_w)
                r = int(50 + ratio * 200)
                g = int(200 - ratio * 80)
                pygame.draw.line(grad, (r, g, 100), (i, 0), (i, height))
            surf.blit(grad, (x, y))
        pygame.draw.rect(surf, (255, 255, 255), (x, y, width, height), 2, border_radius=4)
        draw_text(surf, f"{fmt_size_short(size)} / {max_sz:.1f}\"", (x + width // 2, y + height + 10), font=F14, color=(255, 255, 200))


# ── main game ──────────────────────────────────────────────────────────

class Game:
    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        self.display = pygame.display.set_mode((W, H))
        self.screen = self.display
        pygame.display.set_caption("Eater Quest")
        pygame.event.set_allowed([pygame.KEYDOWN, pygame.KEYUP, pygame.MOUSEBUTTONDOWN, pygame.MOUSEMOTION, pygame.QUIT])
        self.clock = pygame.time.Clock()

        try:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            self.music_splash = pygame.mixer.Sound(os.path.join(script_dir, "splash_theme.mid"))
            self.music_splash.set_volume(0.5)
        except:
            self.music_splash = None

        script_dir = os.path.dirname(os.path.abspath(__file__))
        self.sfx_dice = None
        self.sfx_eating = None
        self.sfx_starvation = None
        self.sfx_levelup = None
        self.sfx_hatch = None
        self.sfx_boost = None
        self.sfx_math_correct = None
        self.sfx_math_wrong = None
        for attr, fname in [("sfx_dice", "dice_roll.ogg"), ("sfx_eating", "sfx_eating.ogg"),
                            ("sfx_starvation", "sfx_starvation.ogg"), ("sfx_levelup", "sfx_levelup.ogg"),
                            ("sfx_hatch", "sfx_hatch.ogg"), ("sfx_boost", "sfx_boost.ogg"),
                            ("sfx_math_correct", "sfx_math_correct.ogg"),
                            ("sfx_math_wrong", "sfx_math_wrong.ogg")]:
            try:
                setattr(self, attr, pygame.mixer.Sound(os.path.join(script_dir, fname)))
            except:
                pass

        self.size = 0.25
        self.total_days = 0
        self.max_size = 0.25
        self.generations = 0
        self.death_reason = ""
        self.last_size_milestone = 0
        self.pending_milestone = 0
        self.celebration_tick = 0
        self.celebration_regrew_fin = False
        self.boosts_eat = []
        self.boosts_escape = []
        self.next_phase = "day"
        self.fin_damaged = False
        self.fin_milestones = {1, 2, 3, 4}
        self.hungry = False

        self.background = OceanBackground()
        self.critter_renderer = CritterRenderer()
        self.splash = SplashState()
        self.egg = EggState()
        self.egg.game = self  # type: ignore
        self.day = DayState(self)
        self.night = NightState(self)
        self.over = GameOverState()
        self.win = WinState()
        self.progress_bar = SizeProgressBar()

        self.boost_calculator = None
        self._shared_boost_used = [False] * 3
        self.phase = "splash"
        self.critters = []
        self._regen_boosts()
        self._setup_fonts_for_small()

    def begin_boost_calculator(self, mode, index, boost):
        state = self.day if mode == "day" else self.night
        # The boost is available only after rolling. It is consumed on Enter.
        if (index >= len(state.boost_used) or state.boost_used[index]
                or self._shared_boost_used[index]):
            return
        if mode == "day" and not state.eater_rolled:
            return
        if mode == "night" and state.phase != "roll_result":
            return
        self.boost_calculator = {
            "mode": mode, "index": index, "boost": Fraction(boost),
            "original": Fraction(state.eater_speed), "answer": "",
            "status": "entry", "elapsed": 0,
        }

    def _calculator_keys(self):
        calc = self.boost_calculator
        if not calc:
            return []
        labels = ["7", "8", "9", "4", "5", "6", "1", "2", "3",
                  "/" if calc["mode"] == "day" else ".", "0", "Back",
                  "Space" if calc["mode"] == "day" else "00", "Enter"]
        keys = []
        # Keypad centered on the native 1080-pixel-wide game canvas.
        for n, label in enumerate(labels):
            if n < 12:
                row, col = divmod(n, 3)
                rect = pygame.Rect(337 + col * 138, 278 + row * 67, 130, 58)
            else:
                rect = pygame.Rect(337 + (n - 12) * 205, 552, 197, 54)
            keys.append((label, rect))
        return keys

    def _calculator_input(self, label):
        calc = self.boost_calculator
        if not calc or calc["status"] != "entry":
            return
        if label == "Back":
            calc["answer"] = calc["answer"][:-1]
        elif label == "Space":
            if calc["answer"] and not calc["answer"].endswith(" "):
                calc["answer"] += " "
        elif label == "Enter":
            original = calc["original"]
            expected = original * calc["boost"]
            ans = calc["answer"].strip()
            valid = False
            if calc["mode"] == "day":
                # Enforce canonical simplified mixed fractions, with whole
                # numbers written without a denominator.
                valid = ans == fmt_speed(expected)
            else:
                # Accept a Night answer within 0.02 of the correct value
                # rounded to two decimal places (ROUND_HALF_UP).
                from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
                target = (Decimal(expected.numerator) / Decimal(expected.denominator)).quantize(
                    Decimal("0.01"), rounding=ROUND_HALF_UP)
                try:
                    entered = Decimal(ans)
                    valid = (entered.is_finite() and
                             abs(entered - target) <= Decimal("0.02"))
                except (InvalidOperation, ValueError):
                    valid = False
            state = self.day if calc["mode"] == "day" else self.night
            idx = calc["index"]
            # Consumed immediately and globally, irrespective of correct/wrong.
            state.boost_used[idx] = True
            self._shared_boost_used[idx] = True
            boost = state.boost_values[idx]
            if boost in state.boosts_available:
                state.boosts_available.remove(boost)
            if valid:
                state.eater_speed = expected
                if calc["mode"] == "day":
                    state.eater_speed_display = fmt_speed(expected)
                    state.pending_boost_mult = 0
                    state.pending_boost_val = 0
                else:
                    if state.chase_result is not None:
                        state.chase_result["eater_final"] = expected
                self.play_boost()
            calc["status"] = "correct" if valid else "wrong"
            calc["correct_answer"] = (fmt_speed(expected) if calc["mode"] == "day"
                                      else format(target, ".2f"))
            calc["elapsed"] = 0
            self.play_calculator_result(valid)
        elif len(calc["answer"]) < 22:
            if label in "0123456789/.":
                if label == "/" and calc["mode"] != "day":
                    return
                if label == "." and calc["mode"] != "night":
                    return
                calc["answer"] += label
            elif label == "00" and calc["mode"] == "night":
                calc["answer"] += "00"

    def _calculator_event(self, event):
        calc = self.boost_calculator
        if not calc:
            return
        if calc["status"] != "entry":
            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 or
                    event.type == pygame.KEYDOWN and event.key in
                    (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE)):
                self.boost_calculator = None
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for label, rect in self._calculator_keys():
                if rect.collidepoint(event.pos):
                    self._calculator_input(label)
                    break
        elif event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self._calculator_input("Enter")
            elif event.key == pygame.K_BACKSPACE:
                self._calculator_input("Back")
            elif event.key == pygame.K_SPACE:
                self._calculator_input("Space")
            elif event.unicode and event.unicode in "0123456789/.":
                self._calculator_input(event.unicode)

    def _draw_calculator(self, surf):
        calc = self.boost_calculator
        if not calc:
            return
        cover = pygame.Surface((W, H), pygame.SRCALPHA)
        cover.fill((2, 12, 31, 153))  # 60% dimming (additional 30 percentage points)
        surf.blit(cover, (0, 0))
        if calc["status"] != "entry":
            if calc["status"] == "correct":
                draw_text(surf, "Correct!", (W // 2, 115), (140, 255, 130), F52)
                y = H // 2 + int(60 * math.sin(calc["elapsed"] * 0.13))
                self.critter_renderer.draw_fish(surf, W // 2, y, 54,
                                               flip_h=True, fin_damaged=self.fin_damaged)
            else:
                draw_text(surf, "Wrong!", (W // 2, 190), (255, 120, 120), F52)
                draw_text(surf, "Speed boost lost.", (W // 2, 255),
                          (255, 200, 160), F32)
                draw_text(surf, "Correct answer:", (W // 2, 322),
                          (220, 230, 255), F28)
                draw_text(surf, calc["correct_answer"], (W // 2, 374),
                          (255, 230, 130), F40)
            draw_text(surf, "Click to continue", (W // 2, H - 58),
                      (225, 235, 255), F24)
            return
        # Native landscape calculator: centered, with generous vertical spacing.
        panel = pygame.Rect(305, 42, 470, 620)
        pygame.draw.rect(surf, (23, 49, 78), panel, border_radius=18)
        pygame.draw.rect(surf, (117, 200, 240), panel, 3, border_radius=18)
        draw_text(surf, "SPEED BOOST CHALLENGE", (W // 2, 93),
                  (255, 230, 140), F28)
        base = fmt_speed(calc["original"]) if calc["mode"] == "day" else f'{float(calc["original"]):.2f}'
        boost = fmt_speed(calc["boost"]) if calc["mode"] == "day" else f'{float(calc["boost"]):.2f}'
        draw_text(surf, f"Eater speed: {base}  x  {boost}  =  ?", (W // 2, 163),
                  (255, 255, 255), F24)
        instruction = ("Enter a simplified mixed number" if calc["mode"] == "day"
                       else "Enter a decimal (rounded to 2 places)")
        draw_text(surf, instruction, (W // 2, 127), (190, 230, 255), F20)
        pygame.draw.rect(surf, (5, 15, 29), (337, 213, 406, 49), border_radius=5)
        draw_text(surf, calc["answer"] + "|", (W // 2, 237),
                  (255, 255, 165), F28)
        for label, rect in self._calculator_keys():
            pygame.draw.rect(surf, (51, 119, 165) if label != "Enter" else (35, 150, 105),
                             rect, border_radius=9)
            pygame.draw.rect(surf, (176, 222, 255), rect, 2, border_radius=9)
            draw_text(surf, label, rect.center, (255, 255, 255), F24)

    def _setup_fonts_for_small(self):
        try:
            global F12
            F12 = game_font(20)
        except:
            F12 = F14

    def _regen_boosts(self):
        b = get_boosts(self.size)
        self.boosts_eat = list(b[:2])
        self.boosts_escape = list(b)

    def check_win(self):
        if self.size >= 4.0:
            self.win.tick = 0
            self.win.particles = []
            self.phase = "win"
        return self.size >= 4.0

    def death(self, reason):
        self.death_reason = reason
        if self.sfx_starvation:
            self.sfx_starvation.play()
        self.phase = "gameover"

    def play_dice(self):
        if self.sfx_dice:
            self.sfx_dice.play()

    def play_eating(self):
        if self.sfx_eating:
            self.sfx_eating.play()

    def play_hatch(self):
        if self.sfx_hatch:
            self.sfx_hatch.play()

    def play_boost(self):
        if self.sfx_boost:
            self.sfx_boost.play()

    def play_calculator_result(self, correct):
        sound = self.sfx_math_correct if correct else self.sfx_math_wrong
        if sound:
            sound.play()

    @property
    def habitat_size(self):
        # The level/habitat does not change mid-day; growth is still recorded.
        return min(self.size, self.last_size_milestone + 0.999)

    def check_level_up(self):
        # Queue progression. It becomes effective only after surviving night.
        new_milestone = min(4, int(self.size))
        if new_milestone > self.last_size_milestone:
            self.pending_milestone = max(self.pending_milestone, new_milestone)
            return True
        return False

    def finish_night(self):
        self.check_level_up()
        if self.pending_milestone > self.last_size_milestone:
            self.last_size_milestone = self.pending_milestone
            self.pending_milestone = 0
            self.celebration_regrew_fin = self.fin_damaged
            if self.fin_damaged:
                self.fin_damaged = False
            self.celebration_tick = 0
            self.phase = "levelup"
            if self.sfx_levelup:
                self.sfx_levelup.play()
        elif self.check_win():
            self.phase = "win"
        else:
            self.phase = "day"
            self.next_day()
            self.day.start(self.critters, self.size, list(self.boosts_escape))

    def draw_levelup(self, surf):
        zone = get_zone(self.last_size_milestone)
        backgrounds = {"open_ocean": self.background.draw_open_ocean,
                       "mangrove": self.background.draw_mangrove,
                       "kelp_forest": self.background.draw_kelp_forest,
                       "coral_reef": self.background.draw_coral_reef}
        backgrounds[zone](surf)
        milestone = self.last_size_milestone
        habitat = get_zone_name(milestone)
        draw_text(surf, "Congratulations!", (W // 2, 105), (255, 235, 130), F40)
        draw_text(surf, f"Eater has now reached {milestone} inches", (W // 2, 154), (255, 255, 240), F28)
        draw_text(surf, "and has moved on to a new habitat:", (W // 2, 190), (220, 245, 255), F22)
        draw_text(surf, f"{habitat}!", (W // 2, 229), (120, 255, 190), F36)
        t = self.celebration_tick
        # Continuous leftward pass; do not switch fish orientation/body colors
        # at the endpoints (the chase sprite consistently uses flip_h=True).
        x = int(W + 150 - (t * 3.0) % (W + 300))
        y = 353 + int(math.sin(t * 0.055) * 26)
        size = fish_display_size(self.size) * 1.65
        self.critter_renderer.draw_fish(surf, x, y, size, flip_h=True,
                                        fin_damaged=False, sad_face=False)
        if self.celebration_regrew_fin:
            draw_text(surf, "And Eater regrew his fin!", (W // 2, 468), (150, 255, 150), F28)
        if t >= 100:
            draw_text(surf, "[Click or tap to continue]", (W // 2, H - 45), (250, 250, 200), F22)

    def next_day(self):
        self._shared_boost_used = [False] * 3
        self.total_days += 1
        if self.size > self.max_size:
            self.max_size = self.size
        self._regen_boosts()
        self.critters = get_critters(self.size, 3)

    def next_day_from_night(self):
        self._shared_boost_used = [False] * 3
        self.total_days += 1
        if self.size > self.max_size:
            self.max_size = self.size
        self._regen_boosts()
        self.critters = get_critters(self.size, 3)
        self.day.start(self.critters, self.size, list(self.boosts_escape))

    def handle_input(self, event):
        if self.boost_calculator is not None:
            self._calculator_event(event)
            return

        if self.phase == "splash":
            if self.splash.handle_event(event):
                self.phase = "egg"
                self.egg.start()

        elif self.phase == "egg":
            self.egg.handle_event(event)
            if self.egg.result == "hatched":
                if self.egg.hatch_wait >= 120:
                    self.play_hatch()
                    self.phase = "day"
                    self.next_day()
                    self.day.start(self.critters, self.size, list(self.boosts_escape))
                    self.egg.start()
            elif self.egg.result == "eaten" and self.egg.awaiting_ack:
                if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                    self.death("minnow")
                    self.phase = "gameover"

        elif self.phase == "day":
            self.day.handle_event(event)
            if self.day.phase == "result":
                self.phase = "night"
                self.night.start()

        elif self.phase == "night":
            self.night.handle_event(event)

        elif self.phase == "levelup":
            if self.celebration_tick >= 100 and event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                if self.check_win():
                    self.phase = "win"
                else:
                    self.phase = "day"
                    self.next_day()
                    self.day.start(self.critters, self.size, list(self.boosts_escape))

        elif self.phase == "gameover":
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                self.restart()

        elif self.phase == "win":
            if self.win.handle_event(event):
                self.restart()

    def update(self):
        if self.boost_calculator is not None:
            calc = self.boost_calculator
            if calc["status"] != "entry":
                calc["elapsed"] += 1
            self.critter_renderer.update()
            return
        self.background.update()
        self.critter_renderer.update()
        if self.phase == "egg":
            self.egg.update()
        elif self.phase == "day":
            self.day.update()
        elif self.phase == "night":
            self.night.update()
        elif self.phase == "levelup":
            self.celebration_tick += 1
        elif self.phase == "gameover":
            self.over.update()
        elif self.phase == "win":
            self.win.update()

    def draw(self):
        if self.phase == "splash":
            self.splash.draw(self.screen)
        elif self.phase == "egg":
            self.egg.draw(self.screen)
        elif self.phase == "day":
            self.day.draw(self.screen)
        elif self.phase == "night":
            self.night.draw(self.screen)
        elif self.phase == "levelup":
            self.draw_levelup(self.screen)
        elif self.phase == "gameover":
            self.over.draw(self.screen, self)
        elif self.phase == "win":
            self.win.draw(self.screen, self)
        if self.boost_calculator is not None:
            self._draw_calculator(self.screen)

    def run(self):
        self.egg.start()
        while True:
            event_list = pygame.event.get()
            for event in event_list:
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                self.handle_input(event)

            self.update()
            self.draw()
            pygame.display.flip()
            self.clock.tick(FPS)

    def restart(self):
        self.boost_calculator = None
        self._shared_boost_used = [False] * 3
        self.size = 0.25
        self.total_days = 0
        self.max_size = 0.25
        self.death_reason = ""
        self.phase = "splash"
        self.splash.tick = 0
        self.generations += 1
        self.fin_damaged = False
        self.last_size_milestone = 0
        self.pending_milestone = 0
        self.celebration_tick = 0
        self.celebration_regrew_fin = False
        self._regen_boosts()
        self.egg.start()
        self.hungry = False


if __name__ == "__main__":
    Game().run()

