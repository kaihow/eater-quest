# Eater Quest — Pygbag Linux build

This is the **original Python/Pygame game** (not the separate JavaScript adaptation), with only browser-runtime changes. The playfield remains 800 x 600; use landscape on iPhone.

## Linux build

```bash
cd ~/kyle
python3 -m venv .venv-eater
source .venv-eater/bin/activate
python -m pip install -U pygbag
python -m pygbag --build eater_quest_pygbag_linux
```

Extract the supplied ZIP so `~/kyle/eater_quest_pygbag_linux/main.py` exists. `--build` writes the static website to `eater_quest_pygbag_linux/build/web/`.

Preview locally:

```bash
cd ~/kyle
python -m pygbag eater_quest_pygbag_linux
```

Visit http://localhost:8000 on Linux. To test iPhone over the local network, host the generated `build/web/` over HTTPS; GitHub Pages is easiest.

## GitHub Pages

Create an **empty public** GitHub repository called `eater-quest` (do not initialize README). Then:

```bash
cd ~/kyle/eater_quest_pygbag_linux/build/web
touch .nojekyll
git init
git branch -M main
git add -A
git commit -m 'Publish Eater Quest Pygbag web build'
git remote add origin https://github.com/YOUR_USERNAME/eater-quest.git
git push -u origin main
```

On GitHub, go to Settings > Pages > Deploy from a branch > main > /(root) > Save. Share `https://YOUR_USERNAME.github.io/eater-quest/`.

## Files

- `main.py`: faithful Pygame source with `asyncio` main loop, optional mixer startup, OGG paths, and touch translation
- `eater_quest_original.py`: untouched original for reference (not loaded by Pygbag)
- six `.ogg` sound effects converted from the supplied WAVs

**Test status:** Python syntax and OGG streams validated; a full Pygbag build/iPhone Safari run could not be executed in this environment. Some mobile browser rendering/audio specifics may still need adjustment. No game states, odds, drawings, or physics were intentionally changed. Safari usually requires user interaction to enable sound.
